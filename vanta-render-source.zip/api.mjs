// Accounts (username + password) and the AI assistant. The AI key never reaches the browser:
// it lives in .env on the server and requests are proxied through /api/ai.
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { scryptSync, randomBytes, timingSafeEqual, createHash } from "node:crypto";
import { fileURLToPath } from "node:url";
import { join } from "node:path";

const here = fileURLToPath(new URL(".", import.meta.url));
try {
  for (const l of readFileSync(join(here, ".env"), "utf8").split(/\r?\n/)) {
    const m = l.match(/^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
} catch {}

const openRouterKey = () => {
  const key = process.env.OPENROUTER_API_KEY?.trim();
  return key && key !== "your-openrouter-api-key" ? key : null;
};

const AI_MODELS = [
  { id: "openai/gpt-4o-mini", name: "GPT-4o mini", vision: true },
  { id: "openai/gpt-4.1-mini", name: "GPT-4.1 mini", vision: true },
  { id: "google/gemini-2.5-flash", name: "Gemini 2.5 Flash", vision: true },
  { id: "anthropic/claude-haiku-5.5", name: "Claude Haiku 5.5", vision: true },
  { id: "deepseek/deepseek-chat", name: "DeepSeek Chat" }
];
const defaultModel = () => process.env.OPENROUTER_MODEL?.trim() || AI_MODELS[0].id;
const availableModels = () => {
  const models = [...AI_MODELS];
  const configured = defaultModel();
  if (!models.some(model => model.id === configured)) {
    models.push({ id: configured, name: `Configured default (${configured})` });
  }
  return models;
};
const accountInfo = user => ({ user, ai: !!openRouterKey(), models: availableModels(), defaultModel: defaultModel() });

const DATA = join(here, "data"), FILE = join(DATA, "users.json"), SESSION_FILE = join(DATA, "sessions.json");
let users = new Map();
try { users = new Map(Object.entries(JSON.parse(readFileSync(FILE, "utf8")))); } catch {}
const persist = () => { mkdirSync(DATA, { recursive: true }); writeFileSync(FILE, JSON.stringify(Object.fromEntries(users))); };
let sessions = new Map();
try { sessions = new Map(Object.entries(JSON.parse(readFileSync(SESSION_FILE, "utf8")))); }
catch (error) {
  if (error.code !== "ENOENT") console.error("Could not load saved login sessions:", error);
}
const persistSessions = () => {
  mkdirSync(DATA, { recursive: true });
  writeFileSync(SESSION_FILE, JSON.stringify(Object.fromEntries(sessions)), { mode: 0o600 });
};
const sessionId = token => createHash("sha256").update(token).digest("hex");
const hits = new Map();
const limited = (key, max, ms) => {
  const now = Date.now(), a = (hits.get(key) || []).filter(t => now - t < ms);
  a.push(now); hits.set(key, a); return a.length > max;
};
const hash = (pw, salt) => scryptSync(pw, salt, 64);
const readJson = (req, max = 65536) => new Promise((ok, no) => {
  let n = 0, b = "";
  req.on("data", c => { n += c.length; if (n > max) { no(new Error("big")); req.destroy(); } else b += c; });
  req.on("end", () => { try { ok(JSON.parse(b || "{}")); } catch (e) { no(e); } });
  req.on("error", no);
});

export async function handleApi(req, res) {
  const url = new URL(req.url, "http://x");
  if (!url.pathname.startsWith("/api/")) return false;
  const send = (code, obj, headers = {}) => { res.writeHead(code, { "content-type": "application/json", "cache-control": "no-store", ...headers }); res.end(JSON.stringify(obj)); return true; };
  const ip = req.socket.remoteAddress || "?";
  const tok = ((req.headers.cookie || "").match(/vanta_session=([a-f0-9]{64})/) || [])[1];
  const id = tok && sessionId(tok);
  const s = id && sessions.get(id);
  const me = s && s.exp > Date.now() ? s.user : null;
  const setCookie = (v, age) => ({ "set-cookie": `vanta_session=${v}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${age}${req.headers["x-forwarded-proto"] === "https" ? "; Secure" : ""}` });

  if (url.pathname === "/api/me") return send(200, accountInfo(me));
  if (req.method !== "POST") return send(405, { error: "POST only" });
  let body;
  try { body = await readJson(req, url.pathname === "/api/ai" && me ? 3e6 : 65536); } catch { return send(400, { error: "Bad request" }); }

  if (url.pathname === "/api/signup" || url.pathname === "/api/login") {
    const signup = url.pathname === "/api/signup";
    if (limited(ip + (signup ? "s" : "l"), signup ? 5 : 12, signup ? 3600e3 : 600e3)) return send(429, { error: "Too many tries. Wait a bit and try again." });
    const u = String(body.username || "").trim().toLowerCase(), pw = String(body.password || "");
    if (!/^[a-z0-9_]{3,20}$/.test(u)) return send(400, { error: "Username must be 3–20 letters, numbers or _" });
    if (pw.length < 6 || pw.length > 72) return send(400, { error: "Password must be 6–72 characters" });
    if (signup) {
      if (users.has(u)) return send(409, { error: "That username is taken" });
      const salt = randomBytes(16);
      users.set(u, { salt: salt.toString("hex"), hash: hash(pw, salt).toString("hex") }); persist();
    } else {
      const rec = users.get(u), salt = rec ? Buffer.from(rec.salt, "hex") : randomBytes(16);
      const got = hash(pw, salt), want = rec ? Buffer.from(rec.hash, "hex") : got;
      if (!rec || !timingSafeEqual(got, want)) return send(401, { error: "Wrong username or password" });
    }
    const t = randomBytes(32).toString("hex");
    sessions.set(sessionId(t), { user: u, exp: Date.now() + 30 * 864e5 });
    persistSessions();
    return send(200, accountInfo(u), setCookie(t, 2592000));
  }
  if (url.pathname === "/api/logout") {
    if (id && sessions.delete(id)) persistSessions();
    return send(200, { ok: true }, setCookie("", 0));
  }

  if (url.pathname === "/api/ai") {
    if (!me) return send(401, { error: "Log in to use the assistant." });
    const key = openRouterKey();
    if (!key) return send(503, { error: "The assistant isn’t set up yet. Add OPENROUTER_API_KEY to the .env file and restart the server." });
    if (limited(me + "a", 20, 60e3)) return send(429, { error: "Slow down a little and try again in a minute." });
    const model = typeof body.model === "string" ? body.model : defaultModel();
    if (!availableModels().some(option => option.id === model)) return send(400, { error: "Choose a supported AI model." });
    const raw = (Array.isArray(body.messages) ? body.messages : []).slice(-20)
      .filter(m => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string" && m.content.trim());
    let msgs = raw.map(m => ({ role: m.role, content: m.content.slice(0, 4000) }));
    while (msgs.length && msgs[0].role !== "user") msgs.shift();
    if (!msgs.length || msgs[msgs.length - 1].role !== "user") return send(400, { error: "Say something first." });
    // A screen snapshot can ride along on the newest message only (never stored, never sent again).
    const shot = raw[raw.length - 1].image;
    if (shot !== undefined) {
      if (typeof shot !== "string" || !/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(shot) || shot.length > 2.5e6) return send(400, { error: "That screen capture couldn’t be read. Try sharing again." });
      if (!availableModels().find(option => option.id === model)?.vision) return send(400, { error: "This model can’t see images. Pick a vision model (GPT-4o mini, GPT-4.1 mini, Gemini or Claude) to use screen sharing." });
      const last = msgs[msgs.length - 1];
      last.content = [{ type: "text", text: last.content }, { type: "image_url", image_url: { url: shot } }];
    }
    try {
      const r = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: { "content-type": "application/json", authorization: `Bearer ${key}` },
        body: JSON.stringify({ model, max_tokens: 1024,
          messages: [{ role: "system", content: "You are the assistant inside Vanta, a learning toolkit for students. Be clear, friendly and concise. Help students understand topics rather than just handing over answers. When the user attaches a screenshot of their screen, use it to answer; describe only what is actually visible and say so if something is unreadable." }, ...msgs] })
      });
      const j = await r.json();
      if (!r.ok) return send(502, { error: (j.error && j.error.message) || "The AI request failed" });
      const content = j.choices?.[0]?.message?.content;
      const text = typeof content === "string" ? content
        : Array.isArray(content) ? content.filter(part => part.type === "text").map(part => part.text).join("") : "";
      if (!text) return send(502, { error: "The AI service returned no text" });
      return send(200, { text });
    } catch { return send(502, { error: "Couldn’t reach the AI service" }); }
  }
  return send(404, { error: "Not found" });
}
