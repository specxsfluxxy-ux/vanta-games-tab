// Vanta server: serves the site, the Scramjet/bare-mux/epoxy files, and a Wisp endpoint.
import { createServer } from "node:http";
import { createReadStream, readFileSync, statSync } from "node:fs";
import { join, resolve, extname, sep } from "node:path";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import { fileURLToPath } from "node:url";
import { baremuxPath } from "@mercuryworkshop/bare-mux/node";
import { epoxyPath } from "@mercuryworkshop/epoxy-transport";
import { server as wisp } from "@mercuryworkshop/wisp-js/server";
import { handleApi } from "./api.mjs";

const here = fileURLToPath(new URL(".", import.meta.url));
const SERAPH_REV = "ae2fcc6d6a9cd051654fcc0519080db1f79cf2a7";
const seraphGames = new Set(JSON.parse(readFileSync(join(here, "public/games/games.json"), "utf8"))
  .filter(game => game && game.source === "seraph" && typeof game.id === "string"
    && /^[A-Za-z0-9][A-Za-z0-9_-]*$/.test(game.id))
  .map(game => game.id));
let scramjetPath;
try { ({ scramjetPath } = await import("@mercuryworkshop/scramjet/path")); }
catch { scramjetPath = join(here, "node_modules/@mercuryworkshop/scramjet/dist"); }

// Don't let the proxy reach your own machine or LAN.
wisp.options.allow_loopback_ips = false;
wisp.options.allow_private_ips = false;

const MOUNTS = [
  ["/scram/", scramjetPath],
  ["/baremux/", baremuxPath],
  ["/epoxy/", epoxyPath],
  ["/", join(here, "public")]
];
const TYPES = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".mjs": "text/javascript", ".css": "text/css",
  ".json": "application/json", ".wasm": "application/wasm", ".png": "image/png", ".svg": "image/svg+xml", ".map": "application/json", ".txt": "text/plain",
  ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".gif": "image/gif", ".webp": "image/webp", ".ico": "image/x-icon", ".avif": "image/avif",
  ".mp3": "audio/mpeg", ".ogg": "audio/ogg", ".wav": "audio/wav", ".mp4": "video/mp4", ".webm": "video/webm",
  ".woff": "font/woff", ".woff2": "font/woff2", ".ttf": "font/ttf", ".otf": "font/otf", ".xml": "application/xml" };

function resolveFile(pathname) {
  for (const [prefix, root] of MOUNTS) {
    if (!pathname.startsWith(prefix)) continue;
    const base = resolve(root);
    let file = resolve(base, "." + sep + decodeURIComponent(pathname.slice(prefix.length)));
    if (file !== base && !file.startsWith(base + sep)) return null;
    try { if (statSync(file).isDirectory()) file = join(file, "index.html"); statSync(file); return file; } catch { if (prefix !== "/") return null; }
  }
  return null;
}

async function serveSeraphAsset(req, res, pathname) {
  const gamePrefix = "/seraph-games/", sharedPrefix = "/seraph-shared/";
  const isGame = pathname.startsWith(gamePrefix);
  if (!isGame && !pathname.startsWith(sharedPrefix)) return false;
  if (req.method !== "GET" && req.method !== "HEAD") {
    res.writeHead(405, { "content-type": "text/plain; charset=utf-8", allow: "GET, HEAD" });
    res.end("Method not allowed");
    return true;
  }

  let parts;
  try { parts = pathname.slice(isGame ? gamePrefix.length : sharedPrefix.length).split("/").map(decodeURIComponent); }
  catch {
    res.writeHead(400, { "content-type": "text/plain; charset=utf-8" });
    res.end("Invalid game path");
    return true;
  }
  if (parts[parts.length - 1] === "") parts.pop();
  const root = parts.shift();
  if (isGame ? !root || !seraphGames.has(root) || !parts.length : !["storage", "images"].includes(root) || !parts.length) {
    res.writeHead(404, { "content-type": "text/plain; charset=utf-8" });
    res.end("Game asset not found");
    return true;
  }
  if (parts.some(part => !part || part === "." || part === ".." || /[\\/]/.test(part))) {
    res.writeHead(400, { "content-type": "text/plain; charset=utf-8" });
    res.end("Invalid game path");
    return true;
  }

  const assetPath = parts.map(encodeURIComponent).join("/");
  const upstreamPath = isGame
    ? `games/${encodeURIComponent(root)}/${assetPath}`
    : `${root}/${assetPath}`;
  const upstreamUrl = `https://raw.githubusercontent.com/a456pur/seraph/${SERAPH_REV}/${upstreamPath}`;
  let upstream, timer;
  try {
    const controller = new AbortController();
    timer = setTimeout(() => controller.abort(), 20000);
    upstream = await fetch(upstreamUrl, { method: req.method, redirect: "error", signal: controller.signal });
  } catch (error) {
    console.error(`Unable to fetch Seraph asset ${upstreamPath}:`, error);
    res.writeHead(502, { "content-type": "text/plain; charset=utf-8" });
    res.end("Game asset temporarily unavailable");
    return true;
  } finally {
    clearTimeout(timer);
  }
  if (!upstream.ok) {
    res.writeHead(upstream.status === 404 ? 404 : 502, { "content-type": "text/plain; charset=utf-8" });
    res.end(upstream.status === 404 ? "Game asset not found" : "Game asset temporarily unavailable");
    return true;
  }

  const contentType = TYPES[extname(parts[parts.length - 1]).toLowerCase()]
    || upstream.headers.get("content-type") || "application/octet-stream";
  const forwardedProto = String(req.headers["x-forwarded-proto"] || "").split(",")[0].trim();
  const protocol = forwardedProto === "https" || forwardedProto === "http"
    ? forwardedProto
    : req.socket.encrypted ? "https" : "http";
  let gameCsp;
  if (contentType.startsWith("text/html")) {
    let origin;
    try { origin = new URL(`${protocol}://${req.headers.host}`).origin; }
    catch {
      res.writeHead(400, { "content-type": "text/plain; charset=utf-8" });
      res.end("Invalid host");
      return true;
    }
    const gamePath = `${origin}/seraph-games/`, sharedPath = `${origin}/seraph-shared/`;
    gameCsp = [
      "sandbox allow-scripts allow-pointer-lock",
      "default-src 'none'",
      `script-src ${gamePath} ${sharedPath} 'unsafe-inline' 'unsafe-eval' data: blob:`,
      `style-src ${gamePath} ${sharedPath} 'unsafe-inline' data:`,
      `img-src ${gamePath} ${sharedPath} data: blob:`,
      `font-src ${gamePath} ${sharedPath} data:`,
      `media-src ${gamePath} ${sharedPath} data: blob:`,
      `connect-src ${gamePath} ${sharedPath} data: blob:`,
      `worker-src ${gamePath} ${sharedPath} blob:`,
      `frame-src ${gamePath} ${sharedPath} blob:`,
      "form-action 'none'",
      `object-src ${gamePath}`,
      `base-uri ${gamePath} ${sharedPath}`
    ].join("; ");
  }
  res.writeHead(200, {
    "content-type": contentType,
    "cache-control": contentType.startsWith("text/html") ? "no-cache" : "public, max-age=31536000, immutable",
    "x-content-type-options": "nosniff",
    "access-control-allow-origin": "null",
    "cross-origin-resource-policy": "cross-origin",
    ...(gameCsp ? { "content-security-policy": gameCsp } : {})
  });
  if (req.method === "HEAD") res.end();
  else if (contentType.startsWith("text/html")) {
    try {
      let html = await upstream.text();
      html = html.replace(/<script\b[^>]*\bsrc=(["'])[^"']*storage\/js\/cloak\.js\1[^>]*>\s*<\/script>/gi, "")
        .replace(/((?:\.\.\/)+)(storage|images)\//g, "/seraph-shared/$2/")
        .replace(/(["'(])\/(storage|images)\//g, "$1/seraph-shared/$2/");
      res.end(html);
    } catch (error) {
      console.error(`Unable to read Seraph game page ${upstreamPath}:`, error);
      res.destroy();
    }
  } else {
    try { await pipeline(Readable.fromWeb(upstream.body), res); }
    catch (error) {
      if (!res.destroyed) console.error(`Unable to stream Seraph asset ${upstreamPath}:`, error);
    }
  }
  return true;
}

const server = createServer(async (req, res) => {
  if (await handleApi(req, res)) return;
  const pathname = new URL(req.url, "http://x").pathname;
  if (await serveSeraphAsset(req, res, pathname)) return;
  const file = resolveFile(pathname);
  if (!file) { res.writeHead(404, { "content-type": "text/plain" }); return res.end("Not found"); }
  res.writeHead(200, {
    "content-type": TYPES[extname(file)] || "application/octet-stream",
    "cache-control": [".html", ".js", ".mjs"].includes(extname(file)) ? "no-cache" : "public, max-age=300"
  });
  createReadStream(file).pipe(res);
});

server.on("upgrade", (req, socket, head) => {
  if (req.url.startsWith("/wisp/")) wisp.routeRequest(req, socket, head);
  else socket.destroy();
});

const PORT = process.env.PORT || 8080;
server.on("error", e => { console.error(e.code === "EADDRINUSE" ? `Port ${PORT} is already in use. Close the other Vanta window (or run with PORT=8081) and try again.` : e); process.exit(1); });
server.listen(PORT, () => console.log(`Vanta running at http://localhost:${PORT}`));
