// Edit this list to change the "What's new" panel. The first entry is the current
// version: bump its version number and the panel shows again for returning visitors.
const UPDATES = [
  {
    version: "1.5.0",
    items: [
      { icon: "i-sidebar", tag: "NEW", title: "Sidebar", text: "Open ⋮ → Settings → Browser and pick Sidebar for vertical tabs down the left. Ctrl+B hides it. It replaces the old Zen layout." },
      { icon: "i-swatch", tag: "CHANGED", title: "A calmer default look", text: "The new default theme, Ink, is flat and solid: no glow, no blur, no gradients, and a plain wordmark on the home page." }
    ]
  },
  {
    version: "1.4.1",
    items: [
      { icon: "i-tabs", tag: "CHANGED", title: "Zen browser redesign", text: "Flatter sidebar, quieter tabs, brand-icon essentials and tinted spaces. Kyro themes were removed." }
    ]
  },
  {
    version: "1.4.0",
    items: [
      { icon: "i-gear", tag: "NEW", title: "Kyro OS settings", text: "Settings now use the Kyro layout: Appearance, Themes, Accessibility, export and import, plus 19 extra Kyro themes and a theme maker." },
      { icon: "i-tabs", tag: "NEW", title: "Zen browser", text: "Open ⋮ → Settings → Browser and pick Zen: a sidebar with vertical tabs, essentials, colour spaces and a floating page. Ctrl+B hides the sidebar." }
    ]
  },
  {
    version: "1.3.0",
    items: [
      { icon: "i-globe-lock", tag: "NEW", title: "Built-in proxy", text: "Pages now open through Scramjet, so sites that block frames can load." }
    ]
  },
  {
    version: "1.2.0",
    items: [
      { icon: "i-swatch", tag: "NEW", title: "22 themes with live previews",
        text: "Open ⋮ → Settings to see every theme as a mini preview and switch with one click. Your pick is remembered." },
      { icon: "i-shapes", tag: "NEW", title: "Redesigned toolbar icons",
        text: "New assistant, split view, bookmarks, cloak and fullscreen icons." },
      { icon: "i-bell", tag: "NEW", title: "What’s new panel",
        text: "This panel shows on your first visit and after each update. Reopen it any time from the ⋮ menu." },
      { icon: "i-broom", tag: "CHANGED", title: "Cleaner home page",
        text: "The ping indicator is gone." }
    ]
  },
  {
    version: "1.1.0",
    items: [
      { icon: "i-layers", title: "Multi-tab browsing", text: "Open, switch and close tabs; each keeps its own history." },
      { icon: "i-globe-lock", title: "Mullvad-style VPN panel", text: "Location picker with a map." },
      { icon: "i-drop", title: "Glass and Graphite themes", text: "Two looks to start with." }
    ]
  },
  {
    version: "1.0.0",
    items: [{ icon: "i-rocket", title: "Vanta.cc launch", text: "Search bar, quick links and the address bar." }]
  }
];
const APP_VERSION = UPDATES[0].version;
