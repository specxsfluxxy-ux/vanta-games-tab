(() => {
  const page = document.getElementById("gamesPage");
  if (!page) return;

  const list = document.getElementById("gmList");
  const grid = document.getElementById("gmGrid");
  const count = document.getElementById("gmCount");
  const empty = document.getElementById("gmEmpty");
  const play = document.getElementById("gmPlay");
  const search = document.getElementById("gmSearch");
  const back = document.getElementById("gmBack");
  const reload = document.getElementById("gmReload");
  const full = document.getElementById("gmFull");
  const title = document.getElementById("gmTitle");
  const frame = document.getElementById("gmFrame");

  const state = {
    loaded: false,
    games: [],
    filtered: [],
    current: null
  };

  const cleanTitle = value => {
    const raw = String(value || "").trim();
    if (!raw) return "Untitled";
    return raw
      .replace(/[-_.]+/g, " ")
      .replace(/\s+/g, " ")
      .replace(/\b\w/g, ch => ch.toUpperCase())
      .trim();
  };

  function setEmpty(message) {
    empty.hidden = !message;
    empty.textContent = message || "";
  }

  function applyFilter() {
    const q = (search ? search.value : "").trim().toLowerCase();
    if (!q) {
      state.filtered = [...state.games];
    } else {
      state.filtered = state.games.filter(game => {
        const haystack = `${game.title || ""} ${game.id || ""}`.toLowerCase();
        return haystack.includes(q);
      });
    }
    renderGames();
  }

  function renderGames() {
    if (!grid) return;
    grid.innerHTML = "";

    const listCount = state.filtered.length;
    if (count) {
      count.textContent = `${listCount} game${listCount === 1 ? "" : "s"}`;
    }

    if (!listCount) {
      const q = (search ? search.value : "").trim();
      setEmpty(q ? `No games match “${q}”.` : "No games available yet.");
      return;
    }

    setEmpty("");

    state.filtered.forEach(game => {
      const card = document.createElement("button");
      card.type = "button";
      card.className = "gm-card";
      card.dataset.id = game.id;
      card.title = cleanTitle(game.title || game.id);

      const thumb = document.createElement("div");
      thumb.className = "th";

      const thumbSrc = typeof game.thumb === "string" && game.thumb ? `/seraph-shared/${game.thumb.replace(/^\//, "")}` : "";
      if (thumbSrc) {
        const img = document.createElement("img");
        img.alt = cleanTitle(game.title || game.id);
        img.loading = "lazy";
        img.src = thumbSrc;
        img.onerror = () => {
          const letter = document.createElement("span");
          letter.textContent = (game.title || game.id || "?").slice(0, 1).toUpperCase();
          img.replaceWith(letter);
        };
        thumb.appendChild(img);
      } else {
        const letter = document.createElement("span");
        letter.textContent = (game.title || game.id || "?").slice(0, 1).toUpperCase();
        thumb.appendChild(letter);
      }

      const name = document.createElement("span");
      name.textContent = cleanTitle(game.title || game.id);

      card.appendChild(thumb);
      card.appendChild(name);
      grid.appendChild(card);
    });
  }

  function openGame(game) {
    if (!game || !play || !list || !frame) return;
    state.current = game;
    title.textContent = cleanTitle(game.title || game.id);
    frame.src = `/seraph-games/${encodeURIComponent(game.id)}/index.html`;
    list.hidden = true;
    play.hidden = false;
  }

  function closeGame() {
    if (!play || !list || !frame) return;
    state.current = null;
    frame.src = "about:blank";
    play.hidden = true;
    list.hidden = false;
    if (search) search.focus();
  }

  async function loadGames() {
    if (state.loaded && state.games.length) {
      applyFilter();
      return;
    }

    try {
      const response = await fetch("/games/games.json", { cache: "no-cache" });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const games = await response.json();
      state.games = Array.isArray(games) ? games.filter(game => game && typeof game.id === "string" && game.id.trim()) : [];
      state.loaded = true;
      state.games.sort((a, b) => cleanTitle(a.title || a.id).localeCompare(cleanTitle(b.title || b.id)));
      applyFilter();
    } catch (error) {
      state.games = [];
      state.loaded = true;
      setEmpty("Unable to load the games list right now.");
      console.error("Games load failed:", error);
    }
  }

  if (search) {
    search.addEventListener("input", applyFilter);
  }

  if (back) {
    back.addEventListener("click", closeGame);
  }

  if (reload) {
    reload.addEventListener("click", () => {
      if (state.current && frame && frame.src) {
        frame.src = frame.src;
      }
    });
  }

  if (full) {
    full.addEventListener("click", async () => {
      if (!frame) return;
      try {
        if (document.fullscreenElement !== frame) {
          await frame.requestFullscreen();
        }
      } catch (error) {
        console.warn("Fullscreen request failed:", error);
      }
    });
  }

  if (grid) {
    grid.addEventListener("click", event => {
      const card = event.target.closest(".gm-card");
      if (!card) return;
      const found = state.filtered.find(game => game.id === card.dataset.id);
      if (found) openGame(found);
    });
  }

  window.loadGames = loadGames;
  setEmpty("");
  loadGames();
})();