/* Animated home-screen backgrounds, rendered with WebGL2 behind the home page.
     topo      Topographic contour map (isolines, index lines, tint bands, hillshade)
     smoke     Fluid smoke: domain-warped noise, rising plumes, cursor vortex
     halftone  Rotated AM halftone dot screen with a duotone second ink
   Pick one in Settings > Appearance > Effects. Colours follow the active theme.

   Tweak per effect by defining window.VANTA_BG before this file loads
   (e.g. in js/config.js):
     window.VANTA_BG = { topo: { density: 40 }, smoke: { speed: 0.4 }, halftone: { dotScale: 1.4 } };  */
(() => {
const DEFAULTS = {
  topo:     { speed: .3, density: 26, indexEvery: 5, indexWeight: .9, lineWeight: 1, tint: .22, relief: .35, scale: 1, warp: .6, paper: .25, mouse: .8, ink: .16, inkIndex: .34, fade: .55 },
  smoke:    { speed: .25, scale: 1.1, warp: 1.1, rise: .3, swirl: .45, contrast: 1.25, softness: .6, mouse: .9, opacity: .42, fade: .5 },
  halftone: { speed: .25, dotScale: 1, angle: 45, duoAngle: 15, duotone: .45, contrast: 1.2, scale: 1, flow: 35, glow: .5, grain: .35, mouse: .9, opacity: .34, fade: .92 }
};
const U_ = window.VANTA_BG || {};
const CFG = {}; for (const k in DEFAULTS) CFG[k] = Object.assign({}, DEFAULTS[k], k === "topo" ? window.VANTA_TOPO : null, U_[k]);
const FPS = 30;

const view = document.querySelector(".view"), home = document.getElementById("home");
if (!view || !home) return;
const root = document.documentElement;

const cv = document.createElement("canvas");
cv.className = "bgfx"; cv.setAttribute("aria-hidden", "true");
view.insertBefore(cv, view.firstChild);
const gl = cv.getContext("webgl2", { alpha: true, premultipliedAlpha: true, antialias: false, depth: false, stencil: false, powerPreference: "low-power" });
if (!gl) { cv.remove(); return; }

/* ---------- shaders ---------- */
const VS = `#version 300 es
in vec2 a; void main(){ gl_Position = vec4(a, 0., 1.); }`;

const HEAD = `#version 300 es
precision highp float;
uniform vec2 uRes; uniform float uTime; uniform vec2 uMouse; uniform float uMouseS; uniform float uFade;
uniform vec3 uInk, uInk2, uTint;
out vec4 o;
float hash(vec3 p){ p = fract(p * .3183099 + .1); p *= 17.; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }
float noise(vec3 x){
  vec3 i = floor(x), f = fract(x); f = f * f * (3. - 2. * f);
  return mix(mix(mix(hash(i), hash(i + vec3(1,0,0)), f.x), mix(hash(i + vec3(0,1,0)), hash(i + vec3(1,1,0)), f.x), f.y),
             mix(mix(hash(i + vec3(0,0,1)), hash(i + vec3(1,0,1)), f.x), mix(hash(i + vec3(0,1,1)), hash(i + vec3(1,1,1)), f.x), f.y), f.z);
}
float fbm(vec3 p){ float a = .5, s = 0.; for (int i = 0; i < 4; i++){ s += a * noise(p); p = p * 2.03 + vec3(17.1, 3.7, 9.2); a *= .5; } return s; }
float fbm3(vec3 p){ float a = .5, s = 0.; for (int i = 0; i < 3; i++){ s += a * noise(p); p = p * 2.03 + vec3(17.1, 3.7, 9.2); a *= .5; } return s; }
mat2 rot(float a){ float c = cos(a), s = sin(a); return mat2(c, -s, s, c); }
float centreFade(){ return 1. - uFade * smoothstep(.55, .0, length((gl_FragCoord.xy / uRes - .5) * vec2(uRes.x / uRes.y, .85))); }
`;

const TOPO = HEAD + `
uniform float uDensity, uIdxEvery, uIdxW, uLineW, uTintA, uRelief, uScale, uWarp, uPaper, uInkA, uInkIdxA;
float height(vec2 p, float t){
  vec3 q = vec3(p, t);
  vec2 w = vec2(fbm(q + vec3(0., 0., 3.1)), fbm(q + vec3(5.2, 1.3, 7.7))) - .5;
  q.xy += w * uWarp * 1.6;
  return fbm(q);
}
void main(){
  vec2 uv = gl_FragCoord.xy / uRes.y;
  float h = height(uv * uScale * 1.6, uTime);
  float d = distance(uv, uMouse);
  h += uMouseS * .3 * exp(-d * d * 8.);
  float f = h * uDensity;
  float fw = max(fwidth(f), 1e-4);
  float k = floor(f + .5);
  float px = abs(f - k) / fw;
  bool idx = uIdxEvery > .5 && mod(k, uIdxEvery) < .5;
  float w = .5 * uLineW + (idx ? uIdxW * .6 : 0.);
  float la = clamp(w + .5 - px, 0., 1.) * smoothstep(1.4, .5, fw);
  la *= idx ? uInkIdxA : uInkA;
  vec3 ink = idx ? uInk2 : uInk;
  float band = uIdxEvery > .5 ? floor(f / uIdxEvery) * uIdxEvery / uDensity : h;
  float ta = uTintA * .5 * clamp((band - .3) * 2.2, 0., 1.);
  vec2 g = vec2(dFdx(h), dFdy(h)) * uRes.y * .35;
  float sh = clamp(dot(g, vec2(1., -1.)) * .7, -1., 1.) * uRelief;
  vec4 c = vec4(uTint * ta, ta);
  float sa = abs(sh) * .09;
  c = vec4((sh > 0. ? vec3(1.) : vec3(0.)) * sa, sa) + c * (1. - sa);
  c = vec4(ink * la, la) + c * (1. - la);
  float n = hash(vec3(gl_FragCoord.xy, 7.)) - .5;
  float pa = abs(n) * .05 * uPaper;
  c = vec4((n > 0. ? vec3(1.) : vec3(0.)) * pa, pa) + c * (1. - pa);
  o = c * centreFade();
}`;

const SMOKE = HEAD + `
uniform float uScale, uWarp, uRise, uSwirl, uContrast, uSoft, uOpacity;
void main(){
  vec2 uv = gl_FragCoord.xy / uRes.y;
  float t = uTime;
  vec2 p = uv * uScale * 1.5;
  // cursor vortex: curl the sample space around the pointer
  vec2 mp = uMouse * uScale * 1.5, dm = uv - uMouse;
  float ang = uMouseS * 2.2 * exp(-dot(dm, dm) * 5.);
  p = mp + rot(ang) * (p - mp);
  p.y -= t * uRise * 2.;
  float sw = fbm3(vec3(p * .6, t * .4)) - .5;
  p = rot(uSwirl * sw * 5.) * p;
  vec2 q = vec2(fbm(vec3(p, t * .6)), fbm(vec3(p + vec2(5.2, 1.3), t * .6 + 3.)));
  vec2 r = vec2(fbm(vec3(p + 3.5 * q + vec2(1.7, 9.2), t * .5)), fbm(vec3(p + 3.5 * q + vec2(8.3, 2.8), t * .5 + 1.)));
  float n = fbm(vec3(p + uWarp * 2.2 * (r - .35), t * .4));
  float dens = clamp((n - mix(.64, .38, uSoft)) * uContrast * 3.2, 0., 1.);
  dens = dens * dens * (3. - 2. * dens);
  float core = dens * dens * dens;
  float wisp = clamp(r.x * 1.4 - .15, 0., 1.);
  vec3 col = mix(mix(uInk, uInk2, wisp), uTint, core);
  float a = dens * uOpacity * centreFade();
  o = vec4(col * a, a);
}`;

const HALF = HEAD + `
uniform float uCell, uAng1, uAng2, uDuo, uContrast, uScale, uFlow, uGlow, uGrain, uOpacity;
float field(vec2 w, float which){
  vec2 q = rot(uFlow) * w;
  q *= vec2(.55, 1.) * uScale * 1.6;
  float t = uTime * (which > .5 ? .8 : 1.);
  float v = fbm3(vec3(q + vec2(which * 7.3, 0.), t)) * 1.5 - .25;
  vec2 gc = vec2(.9 + .35 * sin(uTime * .7 + which), .45 + .25 * cos(uTime * .55));
  v += uGlow * .9 * exp(-pow(length(w - gc) * 1.5, 2.));
  v = (v - .5) * uContrast + .5;
  float dm = distance(w, uMouse);
  v += uMouseS * .4 * exp(-dm * dm * 14.);
  return pow(clamp(v, 0., 1.), 1.7);
}
float screenCov(float ang, float which){
  mat2 R = rot(ang);
  vec2 g = (R * gl_FragCoord.xy) / uCell;
  vec2 base = floor(g - .5);
  float cov = 0.;
  for (int i = 0; i < 2; i++) for (int j = 0; j < 2; j++){
    vec2 c = base + vec2(float(i), float(j)) + .5;
    vec2 w = (transpose(R) * (c * uCell)) / uRes.y;
    float tn = field(w, which) * (which > .5 ? uDuo : 1.);
    float r = sqrt(tn) * .66;
    cov = max(cov, clamp((r - length(g - c)) * uCell + .5, 0., 1.));
  }
  return cov;
}
void main(){
  float a1 = screenCov(uAng1, 0.);
  float a2 = uDuo > .01 ? screenCov(uAng2, 1.) : 0.;
  float gn = hash(vec3(floor(gl_FragCoord.xy * .5), 3.));
  float mot = 1. - uGrain * .35 * gn;
  float f = uOpacity * centreFade() * mot;
  float p1 = a1 * f, p2 = a2 * f * .85;
  vec3 col = uInk * p1 + uInk2 * p2 * (1. - p1);
  o = vec4(col, p1 + p2 * (1. - p1));
}`;

const PROGS = {}, LOC = {};
function build(mode){
  if (PROGS[mode] !== undefined) return PROGS[mode];
  const src = { topo: TOPO, smoke: SMOKE, halftone: HALF }[mode];
  const mk = (t, s) => { const x = gl.createShader(t); gl.shaderSource(x, s); gl.compileShader(x); if (!gl.getShaderParameter(x, gl.COMPILE_STATUS)) { console.warn("[bgfx:" + mode + "]", gl.getShaderInfoLog(x)); return null; } return x; };
  const v = mk(gl.VERTEX_SHADER, VS), f = mk(gl.FRAGMENT_SHADER, src);
  if (!v || !f) return PROGS[mode] = null;
  const p = gl.createProgram(); gl.attachShader(p, v); gl.attachShader(p, f);
  gl.bindAttribLocation(p, 0, "a"); gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) { console.warn("[bgfx:" + mode + "]", gl.getProgramInfoLog(p)); return PROGS[mode] = null; }
  LOC[mode] = {};
  return PROGS[mode] = p;
}
const buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buf);
gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1, 3,-1, -1,3]), gl.STATIC_DRAW);
gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);

let mode = "", prog = null;
function use(m){
  if (m === mode) return;
  const p = build(m); if (!p) { mode = m; prog = null; return; }
  mode = m; prog = p; gl.useProgram(p); dirty = true; colours();
}
function set(n, v){
  if (!prog) return;
  const L = LOC[mode]; if (!(n in L)) L[n] = gl.getUniformLocation(prog, n);
  const l = L[n]; if (l === null) return;
  if (typeof v === "number") gl.uniform1f(l, v); else if (v.length === 2) gl.uniform2fv(l, v); else gl.uniform3fv(l, v);
}

/* ---------- theme colours ---------- */
const probe = document.createElement("i"); probe.style.cssText = "position:absolute;visibility:hidden;pointer-events:none"; document.body.appendChild(probe);
const rgb = c => { probe.style.color = ""; probe.style.color = c; const m = getComputedStyle(probe).color.match(/[\d.]+/g) || [128,128,128]; return [m[0] / 255, m[1] / 255, m[2] / 255]; };
const mixc = (a, b, q) => a.map((v, i) => v * (1 - q) + b[i] * q);
function colours(){
  if (!prog) return;
  const cs = getComputedStyle(root), text = rgb(cs.getPropertyValue("--text").trim() || "#fff"), accent = rgb(cs.getPropertyValue("--accent").trim() || "#e5734b");
  if (mode === "smoke") { set("uInk", mixc(text, accent, .15)); set("uInk2", mixc(text, accent, .7)); set("uTint", accent); }
  else if (mode === "halftone") { set("uInk", text); set("uInk2", accent); set("uTint", accent); }
  else { set("uInk", text); set("uInk2", mixc(text, accent, .45)); set("uTint", accent); }
  dirty = true;
}

/* ---------- sizing + pointer ---------- */
let W = 0, H = 0, dirty = true;
function size(){
  const r = cv.getBoundingClientRect(), dpr = Math.min(window.devicePixelRatio || 1, 1.5);
  const w = Math.max(1, Math.round(r.width * dpr)), h = Math.max(1, Math.round(r.height * dpr));
  if (w !== W || h !== H) { W = cv.width = w; H = cv.height = h; gl.viewport(0, 0, W, H); dirty = true; }
}
new ResizeObserver(size).observe(cv);

let tx = .5, ty = .5, mx = .5, my = .5, ts = 0, ms = 0;
addEventListener("pointermove", e => {
  const r = cv.getBoundingClientRect(); if (!r.width) return;
  const x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
  if (x < 0 || x > 1 || y < 0 || y > 1) { ts = 0; return; }
  tx = x; ty = y; ts = 1;
}, { passive: true });
document.addEventListener("pointerleave", () => ts = 0);
addEventListener("blur", () => ts = 0);

/* ---------- loop ---------- */
const mq = matchMedia("(prefers-reduced-motion: reduce)");
const calm = () => mq.matches || root.classList.contains("no-motion");
const want = () => { const m = root.dataset.bgfx || "topo"; return DEFAULTS[m] ? m : (m === "off" ? "off" : "topo"); };
const live = () => !document.hidden && want() !== "off" && home.offsetParent !== null;

let t = 0, last = 0, wasLive = false;
function frame(now){
  if (!live()) { wasLive = false; return setTimeout(() => requestAnimationFrame(frame), 250); }
  if (!wasLive) { wasLive = true; last = now; size(); }
  requestAnimationFrame(frame);
  use(want());
  const dt = now - last; if (dt < 1000 / FPS) return; last = now;
  if (!prog) return;
  const c = CFG[mode];

  if (!calm()) { t += Math.min(dt, 100) / 1000 * c.speed * .06; dirty = true; }
  const ox = mx, oy = my, os = ms;
  mx += (tx - mx) * .12; my += (ty - my) * .12; ms += (ts * c.mouse - ms) * .08;
  if (Math.abs(mx - ox) + Math.abs(my - oy) + Math.abs(ms - os) > 1e-4) dirty = true;
  if (!dirty) return; dirty = false;

  const ar = W / H, dpr = W / Math.max(1, cv.getBoundingClientRect().width);
  set("uRes", [W, H]); set("uTime", t); set("uMouse", [mx * ar, 1 - my]); set("uMouseS", ms); set("uFade", c.fade);
  if (mode === "topo") {
    set("uDensity", c.density); set("uIdxEvery", c.indexEvery); set("uIdxW", c.indexWeight); set("uLineW", c.lineWeight);
    set("uTintA", c.tint); set("uRelief", c.relief); set("uScale", c.scale); set("uWarp", c.warp); set("uPaper", c.paper);
    set("uInkA", c.ink); set("uInkIdxA", c.inkIndex);
  } else if (mode === "smoke") {
    set("uScale", c.scale); set("uWarp", c.warp); set("uRise", c.rise); set("uSwirl", c.swirl);
    set("uContrast", c.contrast); set("uSoft", c.softness); set("uOpacity", c.opacity);
  } else {
    set("uCell", 9 * c.dotScale * dpr); set("uAng1", c.angle * Math.PI / 180); set("uAng2", c.duoAngle * Math.PI / 180);
    set("uDuo", c.duotone); set("uContrast", c.contrast); set("uScale", c.scale); set("uFlow", c.flow * Math.PI / 180);
    set("uGlow", c.glow); set("uGrain", c.grain); set("uOpacity", c.opacity);
  }
  gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
  gl.drawArrays(gl.TRIANGLES, 0, 3);
}

let pend = false;
new MutationObserver(() => { if (pend) return; pend = true; requestAnimationFrame(() => { pend = false; colours(); }); })
  .observe(root, { attributes: true, attributeFilter: ["data-theme", "style", "class"] });
cv.addEventListener("webglcontextlost", e => { e.preventDefault(); cv.style.display = "none"; });
size(); requestAnimationFrame(frame);
})();
