// Starts Scramjet + the Wisp transport. app.js waits on PROXY.whenReady before loading pages.
const PROXY = { sj: null, ok: false, done: false, error: "" };
const SCRAMJET_DB = "$scramjet";
const SCRAMJET_DB_VERSION = 3;

function useScramjetDatabaseVersion() {
  const open = indexedDB.open.bind(indexedDB);
  indexedDB.open = (name, version, ...options) =>
    open(name, name === SCRAMJET_DB ? SCRAMJET_DB_VERSION : version, ...options);
}

PROXY.reset = async () => {
  await PROXY.whenReady;
  const controller = navigator.serviceWorker.controller;
  if (controller) {
    await new Promise((resolve, reject) => {
      const channel = new MessageChannel();
      const timer = setTimeout(() => {
        channel.port1.close();
        reject(new Error("Could not stop the proxy worker. Close other Vanta tabs, then try again."));
      }, 3000);
      channel.port1.onmessage = () => {
        clearTimeout(timer);
        channel.port1.close();
        resolve();
      };
      controller.postMessage({ type: "vanta:proxy-reset" }, [channel.port2]);
    });
  }
  const registration = await navigator.serviceWorker.getRegistration("/");
  if (registration) await registration.unregister();
  if (PROXY.sj) (await PROXY.sj.openIDB()).close();
  await new Promise((resolve, reject) => {
    const request = indexedDB.deleteDatabase(SCRAMJET_DB);
    let blockedTimer;
    request.onsuccess = () => { clearTimeout(blockedTimer); resolve(); };
    request.onerror = () => { clearTimeout(blockedTimer); reject(request.error || new Error("Could not clear proxy data.")); };
    request.onblocked = () => {
      if (!blockedTimer) blockedTimer = setTimeout(() => reject(new Error("Close other Vanta tabs, then try again.")), 5000);
    };
  });
};

PROXY.whenReady = (async () => {
  try {
    if (!("serviceWorker" in navigator)) throw new Error("service workers need https:// or localhost");
    if (typeof $scramjetLoadController !== "function" || typeof BareMux === "undefined")
      throw new Error("Scramjet files not found - open the site through the Node server (npm start)");
    useScramjetDatabaseVersion();
    const { ScramjetController } = $scramjetLoadController();
    PROXY.sj = new ScramjetController({
      prefix: "/~/scramjet/",
      files: { wasm: "/scram/scramjet.wasm.wasm", all: "/scram/scramjet.all.js", sync: "/scram/scramjet.sync.js" }
    });
    await PROXY.sj.init();
    await navigator.serviceWorker.register("/sw.js", { scope: "/" });
    await navigator.serviceWorker.ready;
    const wisp = (location.protocol === "https:" ? "wss://" : "ws://") + location.host + "/wisp/";
    await new BareMux.BareMuxConnection("/baremux/worker.js").setTransport("/epoxy/index.mjs", [{ wisp }]);
    PROXY.ok = true;
  } catch (e) {
    PROXY.error = String((e && e.message) || e);
    console.warn("[Vanta proxy]", e);
  }
  PROXY.done = true;
  return PROXY.ok;
})();
