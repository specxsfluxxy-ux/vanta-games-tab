const $ = id => document.getElementById(id);
const home = $("home"), addr = $("addr"), note = $("note"), view_ = document.querySelector(".view");
const vpn = { on: false, state: "off", loc: LOCATIONS[0].code };

/* ---- tabs ---- */
const MAX_TABS = 14;
const SESSION_KEY = "vanta-browser-session";
const tabs = []; let active = null, nid = 0;
let sessionSaveTimer = 0;

function newTab(url) {
  if (tabs.length >= MAX_TABS) { flash("Tab limit reached."); return; }
  const t = { id: ++nid, title: "New Tab", hist: [], pos: -1, frame: null, kind: null };
  tabs.push(t);
  activate(t);
  if (url) show(url); else $("q").focus();
}
function writeSession() {
  const savedTabs = tabs.map(t => {
    const start = Math.min(Math.max(0, t.pos), Math.max(0, t.hist.length - 25));
    return {
      title: t.title,
      kind: t.kind === "settings" || t.kind === "games" ? t.kind : null,
      hist: t.hist.slice(start).filter(url => typeof url === "string" && url.length <= 4096 && /^https?:\/\//i.test(url)),
      pos: t.pos < 0 ? -1 : Math.max(0, t.pos - start)
    };
  });
  try {
    localStorage.setItem(SESSION_KEY, JSON.stringify({
      tabs: savedTabs,
      active: Math.max(0, tabs.indexOf(active))
    }));
  } catch (error) {
    console.warn("[Vanta session] Could not save browser tabs.", error);
  }
}
function saveSession() {
  clearTimeout(sessionSaveTimer);
  sessionSaveTimer = setTimeout(writeSession, 150);
}
function restoreSession() {
  let saved;
  try { saved = JSON.parse(localStorage.getItem(SESSION_KEY) || "null"); }
  catch (error) { console.warn("[Vanta session] Could not read saved browser tabs.", error); }
  if (!Array.isArray(saved?.tabs)) return false;
  for (const entry of saved.tabs.slice(0, MAX_TABS)) {
    const hist = Array.isArray(entry.hist)
      ? entry.hist.filter(url => typeof url === "string" && url.length <= 4096 && /^https?:\/\//i.test(url)).slice(-25)
      : [];
    const kind = entry.kind === "settings" || entry.kind === "games" ? entry.kind : null;
    const pos = Number.isInteger(entry.pos) && entry.pos >= 0 && hist.length
      ? Math.min(entry.pos, hist.length - 1)
      : -1;
    tabs.push({
      id: ++nid,
      title: typeof entry.title === "string" ? entry.title.slice(0, 100) : "New Tab",
      hist,
      pos,
      frame: null,
      kind: kind && pos < 0 ? kind : null
    });
  }
  if (!tabs.length) return false;
  active = tabs[Math.min(Math.max(0, Number.isInteger(saved.active) ? saved.active : 0), tabs.length - 1)];
  if (active.pos >= 0) show(active.hist[active.pos], false);
  else activate(active);
  return true;
}
function activate(t) {
  active = t;
  const internal = t.kind === "settings" || t.kind === "games";
  if (!internal && t.pos >= 0 && !t.frame) {
    show(t.hist[t.pos], false);
    return;
  }
  tabs.forEach(x => { if (x.frame) x.frame.style.display = (x === t && x.pos >= 0 && !internal) ? "block" : "none"; });
  home.style.display = (!internal && t.pos < 0) ? "flex" : "none";
  $("settingsPage").classList.toggle("on", t.kind === "settings");
  $("gamesPage").classList.toggle("on", t.kind === "games");
  addr.value = internal ? "vanta://" + t.kind : t.pos >= 0 ? t.hist[t.pos] : "";
  note.style.display = "none";
  renderTabs();
  if (internal && window.renderSettings) window.renderSettings();
  if (t.kind === "games" && window.loadGames) window.loadGames();
  saveSession();
}
function closeTab(t) {
  const i = tabs.indexOf(t); if (i < 0) return;
  t.frame?.remove(); tabs.splice(i, 1);
  if (!tabs.length) { newTab(); return; }
  if (active === t) activate(tabs[Math.min(i, tabs.length - 1)]); else renderTabs();
  saveSession();
}
function renderTabs() {
  const list = $("tablist");
  list.textContent = "";
  tabs.forEach(t => {
    const el = document.createElement("div");
    el.className = "tab"; el.setAttribute("role", "tab"); el.tabIndex = 0;
    el.setAttribute("aria-selected", t === active); el.dataset.id = t.id; el.title = t.title;
    el.innerHTML = `${t.kind === "settings" ? '<svg class="tab-ic"><use href="#i-gear"/></svg>' : '<img src="assets/favicon.png" alt="">'}<span></span><button class="x" aria-label="Close tab" tabindex="-1"><svg><use href="#i-x"/></svg></button>`;
    el.querySelector("span").textContent = t.title;
    list.appendChild(el);
  });
}
$("tablist").addEventListener("click", e => {
  const el = e.target.closest(".tab"); if (!el) return;
  const t = tabs.find(x => x.id == el.dataset.id); if (!t) return;
  if (e.target.closest(".x")) closeTab(t); else if (t !== active) activate(t);
});
$("tablist").addEventListener("auxclick", e => {
  if (e.button !== 1) return;
  const el = e.target.closest(".tab"); const t = el && tabs.find(x => x.id == el.dataset.id); if (t) closeTab(t);
});
$("tablist").addEventListener("keydown", e => {
  const el = e.target.closest(".tab"); if (!el) return;
  const t = tabs.find(x => x.id == el.dataset.id);
  if (e.key === "Enter" || e.key === " ") { e.preventDefault(); activate(t); }
  if (e.key === "Delete") closeTab(t);
});
$("newTab").onclick = () => newTab();

/* ---- navigation ---- */
function toUrl(v) {
  v = v.trim(); if (!v) return null;
  if (/^https?:\/\//i.test(v)) return v;
  if (/^[\w-]+(\.[\w-]+)+(\/.*)?$/.test(v)) return "https://" + v;
  return SEARCH_URL + encodeURIComponent(v);
}
function frameSrc(u) { return PROXY.ok && (!window.VANTA_PROXY_ON || VANTA_PROXY_ON()) ? PROXY.sj.encodeUrl(u) : u; }
function flash(msg) {
  note.textContent = msg; note.style.display = "block";
  clearTimeout(flash.t); flash.t = setTimeout(() => note.style.display = "none", 6000);
}
function show(u, push = true) {
  const t = active;
  t.kind = null;
  if (push) { t.hist.splice(t.pos + 1); t.hist.push(u); t.pos = t.hist.length - 1; }
  if (!t.frame) {
    t.frame = document.createElement("iframe");
    t.frame.className = "page-frame"; t.frame.title = "Page"; t.frame.referrerPolicy = "no-referrer";
    t.frame.allow = "storage-access; autoplay; fullscreen; encrypted-media; picture-in-picture; gamepad; pointer-lock; clipboard-read; clipboard-write";
    view_.insertBefore(t.frame, home);
  }
  if (PROXY.done) t.frame.src = frameSrc(u);
  else { t.frame.src = "about:blank"; PROXY.whenReady.then(() => { if (t.hist[t.pos] === u) t.frame.src = frameSrc(u); }); }
  t.title = u.replace(/^https?:\/\/(www\.)?/, "").split("/")[0] || u;
  activate(t);
  if (PROXY.done && !PROXY.ok) flash("Proxy is off (" + PROXY.error + "). If the page stays blank, that site blocks frames.");
}
function goHome() {
  active.kind = null; active.pos = -1; active.title = "New Tab";
  active.frame && (active.frame.src = "about:blank");
  activate(active); $("q").focus();
}
const go = v => {
  if (/^(vanta|study):\/\/settings\/?$/i.test(v.trim())) return openSettingsTab();
  if (/^vanta:\/\/games\/?$/i.test(v.trim())) return openGamesTab();
  const u = toUrl(v); if (u) show(u);
};

$("searchForm").addEventListener("submit", e => { e.preventDefault(); go($("q").value); $("q").value = ""; });
addr.addEventListener("keydown", e => { if (e.key === "Enter") go(addr.value); });
document.querySelectorAll(".tile").forEach(t => t.addEventListener("click", () => show(t.dataset.url)));
$("homeBtn").onclick = goHome;
$("back").onclick = () => {
  if (active.pos > 0) { active.pos--; show(active.hist[active.pos], false); }
  else if (active.pos === 0) goHome();
};
$("fwd").onclick = () => { if (active.pos < active.hist.length - 1) { active.pos++; show(active.hist[active.pos], false); } };
$("reload").onclick = () => { if (active.pos >= 0 && active.frame) active.frame.src = active.frame.src; };

/* ---- three-dots menu ---- */
const menu = $("menu"), menuBtn = $("menuBtn");
const setMenu = o => { menu.classList.toggle("open", o); menuBtn.setAttribute("aria-expanded", o); };
menuBtn.onclick = e => { e.stopPropagation(); setMenu(!menu.classList.contains("open")); };
document.addEventListener("click", e => { if (!menu.contains(e.target)) setMenu(false); });
document.addEventListener("keydown", e => { if (e.key === "Escape") { setMenu(false); closeVpn(); closeUpdates(); } });

/* ---- settings / themes ---- */
const THEMES = [
  { id: "ink", name: "Ink", dark: true }, { id: "grey", name: "Graphite", dark: true },
  { id: "midnight", name: "Midnight", dark: true }, { id: "aurora", name: "Aurora", dark: true },
  { id: "sunset", name: "Sunset", dark: true }, { id: "ocean", name: "Ocean", dark: true },
  { id: "forest", name: "Forest", dark: true }, { id: "rose", name: "Rose", dark: true },
  { id: "violet", name: "Violet", dark: true }, { id: "mocha", name: "Mocha", dark: true },
  { id: "frost", name: "Frost", dark: true }, { id: "crimson", name: "Crimson", dark: true },
  { id: "amber", name: "Amber", dark: true }, { id: "cyber", name: "Cyber", dark: true },
  { id: "oled", name: "OLED Black", dark: true },
  { id: "light", name: "Light", dark: false }, { id: "paper", name: "Paper", dark: false },
  { id: "mint", name: "Mint", dark: false }, { id: "lavender", name: "Lavender", dark: false },
  { id: "sand", name: "Sand", dark: false }, { id: "sky", name: "Sky", dark: false },
  { id: "blush", name: "Blush", dark: false }
];
function setTheme(t) {
  if (t === "glass" || !THEMES.some(x => x.id === t)) t = "ink";
  document.documentElement.dataset.theme = t;
  try { localStorage.setItem("vanta-theme", t); } catch {}
  document.querySelectorAll(".theme").forEach(b => b.setAttribute("aria-checked", b.dataset.pick === t));
}
/* Settings is a page that lives in its own browser tab (vanta://settings).
   js/settings.js fills it in. If a Settings tab is already open we just switch to it;
   if the current tab is an empty New Tab we reuse that one, like Chrome does. */
function openSettingsTab(section) {
  setMenu(false);
  let t = tabs.find(x => x.kind === "settings");
  if (!t) {
    if (active && !active.kind && active.pos < 0) t = active;
    else {
      if (tabs.length >= MAX_TABS) { flash("Tab limit reached."); return; }
      t = { id: ++nid, hist: [], pos: -1, frame: null };
      tabs.push(t);
    }
    t.kind = "settings"; t.title = "Settings";
  }
  if (section && window.gotoSettings) window.gotoSettings(section);
  activate(t);
}
$("openSettings").onclick = () => openSettingsTab();

function openGamesTab() {
  setMenu(false);
  let t = tabs.find(x => x.kind === "games");
  if (!t) {
    if (active && !active.kind && active.pos < 0) t = active;
    else {
      if (tabs.length >= MAX_TABS) { flash("Tab limit reached."); return; }
      t = { id: ++nid, hist: [], pos: -1, frame: null };
      tabs.push(t);
    }
    t.kind = "games"; t.title = "Games";
  }
  activate(t);
  if (window.loadGames) window.loadGames();
}
$("gamesBtn").onclick = $("openGames").onclick = openGamesTab;

/* ---- what's new ---- */
const SEEN_KEY = "vanta-seen-version";
function renderUpdates() {
  const [latest, ...older] = UPDATES;
  const item = (i, n) => `<li class="upd-i" style="--i:${n}"><span class="upd-ic"><svg><use href="#${i.icon}"/></svg></span><div><h3>${i.title}${i.tag ? `<em class="badge${i.tag === "NEW" ? "" : " alt"}">${i.tag}</em>` : ""}</h3><p>${i.text}</p></div></li>`;
  $("updVer").textContent = "v" + latest.version;
  $("updBody").innerHTML = `<ul class="upd-list">${latest.items.map(item).join("")}</ul>` + (older.length
    ? `<details class="earlier"><summary>Earlier updates</summary>${older.map(u => `<div class="earlier-v"><h4>v${u.version}</h4><ul>${u.items.map(i => `<li><b>${i.title}.</b> ${i.text}</li>`).join("")}</ul></div>`).join("")}</details>` : "");
}
function openUpdates() { setMenu(false); renderUpdates(); $("updScrim").classList.add("open"); $("closeUpd").focus(); }
function closeUpdates() {
  if (!$("updScrim").classList.contains("open")) return;
  $("updScrim").classList.remove("open");
  try { localStorage.setItem(SEEN_KEY, APP_VERSION); } catch {}
}
$("openUpdates").onclick = openUpdates;
$("menuVer").textContent = "v" + APP_VERSION;
$("closeUpd").onclick = closeUpdates;
$("updScrim").addEventListener("click", e => { if (e.target === $("updScrim")) closeUpdates(); });

/* ---- Mullvad panel ---- */
const CHK = '<svg class="chk" viewBox="0 0 24 24"><path d="M4 12.500l5 5L20 6.500"/></svg>';
const locs = $("locs");
LOCATIONS.forEach(l => {
  const li = document.createElement("li");
  li.innerHTML = `<button class="mv-loc" role="radio" aria-checked="${l.code === vpn.loc}" data-c="${l.code}">${CHK}<span>${l.name}</span><em>${l.city}</em></button>`;
  locs.appendChild(li);
});
const view = name => { $("viewMain").hidden = name !== "main"; $("viewSelect").hidden = name !== "select";  };

/* map: dotted world, camera glides to the chosen city */
$("mvLand").setAttribute("d", MAP_PATH);
const mapSvg = $("mvMap"), mark = $("mvMark");
const cam = { x: 0, y: 0 }; let camRaf = 0;
const locNow = () => LOCATIONS.find(x => x.code === vpn.loc);
function applyCam() {
  const r = mapSvg.getBoundingClientRect(); if (!r.width) return;
  const w = 64, h = w * r.height / r.width;
  mapSvg.setAttribute("viewBox", `${cam.x - w / 2} ${cam.y - h * 0.25} ${w} ${h}`);
}
function moveMap(animate = true) {
  const l = locNow(), tx = l.lon + 180, ty = 90 - l.lat;
  mark.setAttribute("transform", `translate(${tx} ${ty})`);
  cancelAnimationFrame(camRaf);
  if (!animate || (!cam.x && !cam.y)) { cam.x = tx; cam.y = ty; applyCam(); return; }
  const sx = cam.x, sy = cam.y, t0 = performance.now();
  (function step(t) {
    const k = Math.min(1, (t - t0) / 600), e = 1 - Math.pow(1 - k, 3);
    cam.x = sx + (tx - sx) * e; cam.y = sy + (ty - sy) * e; applyCam();
    if (k < 1) camRaf = requestAnimationFrame(step);
  })(t0);
}
locs.addEventListener("click", e => {
  const b = e.target.closest(".mv-loc"); if (!b) return;
  vpn.loc = b.dataset.c;
  locs.querySelectorAll(".mv-loc").forEach(x => x.setAttribute("aria-checked", x === b));
  view("main"); render(); moveMap(true);
  if (vpn.on) reroute();
});
$("switchLoc").onclick = () => view("select");
$("backSel").onclick = () => view("main");
function render() {
  const l = locNow();
  $("vpn").dataset.state = vpn.state;
  $("vpnStatus").textContent = { off: "UNSECURED CONNECTION", connecting: "CREATING SECURE CONNECTION", on: "SECURE CONNECTION" }[vpn.state];
  $("mvCountry").textContent = l.name; $("mvCity").textContent = l.city;
  $("mvSrvName").textContent = l.srv; $("mvIn").textContent = l.inIp; $("mvOut").textContent = l.outIp;
  $("mvDevice").textContent = DEVICE_NAME; $("mvTime").textContent = TIME_LEFT;
  $("connect").textContent = vpn.state === "off" ? "Secure my connection" : vpn.state === "connecting" ? "Cancel" : "Disconnect";
  $("menuPill").textContent = vpn.on ? "On" : "Off";
  $("menuPill").classList.toggle("on", vpn.on);
}
$("mvSrv").onclick = () => { const o = $("mvDet").hidden; $("mvDet").hidden = !o; $("mvSrv").setAttribute("aria-expanded", o); };
function openVpn() { setMenu(false); $("mvNotice").hidden = true; $("scrim").classList.add("open"); view("main"); render(); moveMap(false); $("connect").focus(); }
function closeVpn() { $("scrim").classList.remove("open"); }
$("openVpn").onclick = openVpn;
$("closeVpn").onclick = closeVpn;
$("scrim").addEventListener("click", e => { if (e.target === $("scrim")) closeVpn(); });
let connTimer = 0;
const reroute = () => { if (MULLVAD_PROXY && active.pos >= 0) show(active.hist[active.pos], false); };
function startConnect() {
  clearTimeout(connTimer);
  vpn.state = "connecting"; vpn.on = false; render();
  connTimer = setTimeout(() => { vpn.state = "on"; vpn.on = true; render(); reroute(); }, 1700);
}
$("connect").onclick = () => {
  clearTimeout(connTimer);
  if (vpn.state !== "off") { vpn.state = "off"; vpn.on = false; }
  else { startConnect(); return; }
  render(); reroute();
};
$("reconnect").onclick = startConnect;
render();
addEventListener("resize", () => applyCam());

/* ---- status ---- */
addEventListener("online", () => $("statusDot").classList.remove("off"));
addEventListener("offline", () => $("statusDot").classList.add("off"));

$("gotIt").onclick = closeUpdates;

PROXY.whenReady.then(ok => { if (!ok) flash("Proxy is off (" + PROXY.error + "). Pages load directly."); });
addEventListener("pagehide", writeSession);
setTimeout(() => { if (!restoreSession()) newTab(); }, 0);
let seenVer = null; try { seenVer = localStorage.getItem(SEEN_KEY); } catch {}
if (seenVer !== APP_VERSION) setTimeout(openUpdates, 450);
