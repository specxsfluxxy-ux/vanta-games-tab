/* Settings (ported from Kyro OS) + Sidebar layout. Loads after app.js. */
(() => {
const KEY = "vanta-settings";
const DEF = { theme: "ink", kyro: "", accent: "", blur: 22, grain: false, background: "halftone", contrast: false, motion: false, layout: "tabs", sbw: 248, proxy: true, adblock: true, adlevel: "ads", engine: "google", collapsed: false, custom: [] };
let S = Object.assign({}, DEF);
let saved = {};
try { saved = JSON.parse(localStorage.getItem(KEY)) || {}; Object.assign(S, saved); } catch {}
if (!Object.prototype.hasOwnProperty.call(saved, "background") && typeof saved.halftone === "boolean")
  S.background = saved.halftone ? "halftone" : "none";
if (!["none", "halftone", "topo", "smoke"].includes(S.background)) S.background = "halftone";
delete S.halftone;
if (S.theme === "glass") S.theme = "ink";
if (S.layout !== "tabs" && S.layout !== "sidebar") S.layout = "tabs";
try { const q = new URLSearchParams(location.search).get("layout"); if (q === "tabs" || q === "sidebar") S.layout = q; } catch {}
window.VANTA_PROXY_ON = () => S.proxy !== false;
const save = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch {} };
const pushAdblock = () => {
  if (!("serviceWorker" in navigator)) return;
  const msg = { type: "vanta:adblock", on: S.adblock !== false, level: S.adlevel === "strict" ? "strict" : "ads" };
  navigator.serviceWorker.ready.then(r => (navigator.serviceWorker.controller || r.active || {}).postMessage?.(msg)).catch(() => {});
};
window.VANTA_BLOCKED = 0;
if ("serviceWorker" in navigator) navigator.serviceWorker.addEventListener("message", e => {
  if (e.data && e.data.type === "vanta:blocked") { window.VANTA_BLOCKED = e.data.n; const el = document.getElementById("adCount"); if (el) el.textContent = e.data.n; }
});
const esc = v => String(v).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const hex = c => /^#[0-9a-f]{6}$/i.test(c || "");

/* Kyro OS themes: [id, name, background, panel, accent] */
const KT = []; // no Kyro themes; only your own custom ones use this machinery
const kdef = id => KT.find(t => t[0] === id) || (S.custom.find(t => t.id === id) && (c => [c.id, c.name, c.bg, c.panel, c.accent])(S.custom.find(t => t.id === id)));

function apply() {
  const r = document.documentElement, st = r.style;
  const k = S.kyro && kdef(S.kyro);
  if (k) {
    r.dataset.theme = "kyro";
    st.setProperty("--bg", k[2]); st.setProperty("--text", k[0] === "graphite" ? "#ece8de" : "#eceef1"); st.setProperty("--pill", "12px");
    ["--panel","--bar","--tabs"].forEach(v => st.setProperty(v, k[3])); st.setProperty("--dlg", k[3]); st.setProperty("--k1", k[3]); st.setProperty("--accent", k[4]);
    st.setProperty("--glow", `color-mix(in srgb,${k[4]} 18%,transparent)`); st.setProperty("--glow2", `color-mix(in srgb,${k[3]} 70%,transparent)`);
    st.setProperty("--tile-fg", k[4]);
  } else {
    ["--bg","--text","--glow","--glow2","--tile-fg","--accent","--panel","--bar","--tabs","--dlg","--pill","--k1"].forEach(p => st.removeProperty(p));
    setTheme(S.theme);
  }
  const acc = S.accent || "";
  if (acc) st.setProperty("--accent", acc); else if (!k) st.removeProperty("--accent");
  st.setProperty("--blur", `blur(${S.blur}px) saturate(150%)`);
  r.classList.toggle("hi-contrast", S.contrast); r.classList.toggle("no-motion", S.motion);
  r.dataset.browserBackground = S.background;
  r.dataset.bgfx = S.background === "topo" || S.background === "smoke" ? S.background : "off";
  document.body.classList.toggle("grain", S.grain);
  r.dataset.layout = S.layout;
  S.collapsed && S.layout === "sidebar" ? r.setAttribute("data-sb-collapsed", "") : r.removeAttribute("data-sb-collapsed");
  st.setProperty("--sbw", S.sbw + "px"); S.accent ? st.setProperty("--sa-acc", S.accent) : st.removeProperty("--sa-acc");
}

if (typeof PROXY !== "undefined" && PROXY.whenReady) PROXY.whenReady.then(pushAdblock);
/* ---- Sidebar layout: brand row, footer, collapse ---- */
const openSet = () => document.getElementById("openSettings").click();
const sbBtn = (cls, title, icon, label) => { const b = document.createElement("button"); b.className = cls; b.title = title; b.setAttribute("aria-label", title); b.innerHTML = `<svg><use href="#${icon}"/></svg>${label ? `<span>${label}</span>` : ""}`; return b; };
const setCollapsed = v => { S.collapsed = v; save(); apply(); };
const brand = document.createElement("div"); brand.className = "sb-brand";
brand.innerHTML = '<img src="assets/favicon.png" alt=""><b>Vanta<i>.cc</i></b>';
const hide = sbBtn("ib sb-hide", "Hide sidebar (Ctrl+B)", "i-sidebar"); hide.onclick = () => setCollapsed(true); brand.appendChild(hide);
document.querySelector(".bar").before(brand);
const foot = document.createElement("div"); foot.className = "sb-foot";
const PERSON = '<svg class="pfp" viewBox="0 0 100 100" aria-hidden="true"><circle cx="50" cy="50" r="50" fill="#d2d2d2"/><circle cx="50" cy="43" r="18.7" fill="#9b9b9b"/><path d="M12.73 83.33A39 26 0 0 1 87.27 83.33A50 50 0 0 1 12.73 83.33Z" fill="#9b9b9b"/></svg>';
foot.innerHTML = '<button class="sb-prof" id="sbProf" title="Account" aria-label="Account"><span class="sb-av">' + PERSON + '<i class="sb-st" id="sbSt"></i></span><span class="sb-who"><b id="sbName">Guest</b><small id="sbStat">Online</small></span></button>';
const gearBtn = sbBtn("ib sb-gear", "Settings (Ctrl+,)", "i-dots"); gearBtn.onclick = e => { e.stopPropagation(); openSet(); };
foot.appendChild(gearBtn); document.querySelector(".tabs").after(foot);
foot.querySelector("#sbProf").onclick = () => document.getElementById("openLogin").click();
const sbNet = () => { const on = navigator.onLine; foot.querySelector("#sbSt").classList.toggle("off", !on); foot.querySelector("#sbStat").textContent = on ? "Online" : "Offline"; };
addEventListener("online", sbNet); addEventListener("offline", sbNet); sbNet();
const peek = sbBtn("ib sb-peek", "Show sidebar (Ctrl+B)", "i-sidebar"); peek.onclick = () => setCollapsed(false); document.body.appendChild(peek);
addEventListener("keydown", e => {
  if (!(e.ctrlKey || e.metaKey)) return;
  if (e.key === ",") { e.preventDefault(); openSet(); return; }
  if (S.layout !== "sidebar") return;
  if (e.key === "b") { e.preventDefault(); setCollapsed(!S.collapsed); }
  if (e.key === "l") { e.preventDefault(); if (S.collapsed) setCollapsed(false); addr.focus(); addr.select(); }
});

/* ---- search engine ---- */
const ENGINES = { google: SEARCH_URL, duckduckgo: "https://duckduckgo.com/?q=", bing: "https://www.bing.com/search?q=", brave: "https://search.brave.com/search?q=" };
const _toUrl = toUrl;
toUrl = v => { const u = _toUrl(v); return u && u.startsWith(SEARCH_URL) ? (ENGINES[S.engine] || SEARCH_URL) + u.slice(SEARCH_URL.length) : u; };

/* ---- Settings window ---- */
const tg = (k, on) => `<button class="os-tg" role="switch" aria-checked="${!!on}" data-tg="${k}"><i></i></button>`;
const seg = (k, opts) => `<div class="sa-seg">${opts.map(([v, l]) => `<button data-sg="${k}" data-v="${v}" class="${String(S[k]) === v ? "on" : ""}">${l}</button>`).join("")}</div>`;
const rng = (k, min, max, u) => `<div class="sa-range"><input type="range" data-rg="${k}" min="${min}" max="${max}" value="${S[k]}" data-u="${u}"><span>${S[k]}${u}</span></div>`;
const row = (t, s, c) => `<div class="sa-row"><div><div class="sa-t">${t}</div><div class="sa-s">${s}</div></div>${c}</div>`;
const bgChoice = (id, name, description) => `<button class="bg-choice${S.background === id ? " on" : ""}" data-bg="${id}" aria-pressed="${S.background === id}"><span class="bg-swatch bg-swatch-${id}" aria-hidden="true"></span><span class="bg-choice-copy"><b>${name}</b><small>${description}</small></span></button>`;
const card = (id, name, bg, p, acc, on, del) => `<div class="th-wrap"><button class="th-card${on ? " on" : ""}" data-k="${esc(id)}" title="${esc(name)}"><span class="th-prev" style="background:${bg}"><i style="background:${p}"></i><i style="background:${mix(p, "#ffffff", .05)}"></i><i style="background:${mix(p, "#ffffff", .11)}"></i><b style="background:${acc}"></b></span><span class="th-name">${esc(name)}</span></button>${del ? `<button class="th-del" data-del="${esc(id)}" title="Delete theme">×</button>` : ""}</div>`;
const mix = (a, b, q) => { const x = parseInt(a.slice(1), 16), y = parseInt(b.slice(1), 16), f = sh => Math.round(((x >> sh) & 255) * (1 - q) + ((y >> sh) & 255) * q).toString(16).padStart(2, "0"); return "#" + f(16) + f(8) + f(0); };
let draft = { name: "My theme", bg: "#101014", panel: "#1a1a22", accent: "#6db3ff" }, cur = "appearance";
const SEC = [
  ["appearance", "palette", "Appearance", () =>
    '<p class="sa-grp">Colour</p>' +
    row("Accent colour", "Buttons, highlights and active states", `<div class="sa-sw">${["", "#ff5a36", "#e0a43a", "#4fae6a", "#3aa1c9", "#7b6cf0", "#d65a9c", "#ece8de"].map(c => `<button data-ac="${c}" class="${S.accent === c ? "on" : ""}" style="background:${c || "var(--blue)"}" title="${c || "Theme default"}"></button>`).join("")}</div>`) +
    row("Theme", `Pick from ${THEMES.length} themes or make your own`, `<button class="sa-btn" data-go="themes">Open Themes</button>`) +
    '<p class="sa-grp">Effects</p>' +
    row("Glass blur", "Frosted-glass strength on bars and dialogs", rng("blur", 0, 40, "px")) +
    row("Film grain", "A fine texture over the whole page", tg("grain", S.grain))],
  ["browser", "globe", "Browser", () => {
    const sb = (...x) => row(...x).replace('class="sa-row"', 'class="sa-row' + (S.layout === "sidebar" ? "" : " sa-off") + '"');
    return '<p class="sa-grp">Connection</p>' +
      row("Proxy", PROXY.done ? (PROXY.ok ? "Load pages through the built-in proxy so blocked sites can open" : "Proxy is not running: " + esc(PROXY.error)) : "Starting…", tg("proxy", S.proxy)) +
      row("Fix proxy", "Clear saved proxy data and reload. Use this if pages won’t load", `<button class="sa-btn" data-act="fixproxy">Reset</button>`) +
      row("Search engine", "Used when you type a search in the address bar", seg("engine", [["google", "Google"], ["duckduckgo", "DuckDuckGo"], ["bing", "Bing"], ["brave", "Brave"]])) +
      '<p class="sa-grp">Privacy</p>' +
      row("Ad blocker", "Blocks known ad and tracker servers on pages opened through the proxy", tg("adblock", S.adblock !== false)) +
      (S.adblock !== false ? row("Blocking level", "Ads only is safest. Ads and trackers also blocks analytics and may break a few sites", seg("adlevel", [["ads", "Ads"], ["strict", "Ads + trackers"]])) +
      row("Blocked this session", "Requests stopped since you opened Vanta", `<span class="sa-info" id="adCount">${window.VANTA_BLOCKED || 0}</span>`) : "") +
      row("Open Vanta in about:blank", "Open Vanta in a blank-address tab", `<button class="sa-btn" data-act="openBlank">Open</button>`) +
      '<p class="sa-grp">Layout</p>' +
      row("Tab layout", "Tabs along the top, or a Sidebar down the left with vertical tabs", seg("layout", [["tabs", "Top tabs"], ["sidebar", "Sidebar"]])) +
      sb("Sidebar width", "How wide the Sidebar is", rng("sbw", 208, 340, "px")) +
      sb("Hide sidebar", "Give the page the whole window. Ctrl+B brings it back", tg("collapsed", S.collapsed));
  }],
  ["themes", "swatch", "Themes", () => {
    const vt = THEMES.map(t => `<button class="theme" data-pick="${t.id}" aria-checked="${!S.kyro && S.theme === t.id}"><span class="pv" data-theme="${t.id}"><span class="pv-tabs"><i class="pv-tab"></i></span><span class="pv-bar"><i class="pv-addr"></i></span><span class="pv-logo">Vanta<b>.cc</b></span><span class="pv-search"></span></span><b>${t.name}</b></button>`).join("");
    return `<p class="sa-grp">Built-in <small>${THEMES.length}</small></p><div class="themes">${vt}</div>
    ${S.custom.length ? `<p class="sa-grp">Your themes <small>${S.custom.length}</small></p><div class="th-grid">${S.custom.map(t => card(t.id, t.name, t.bg, t.panel, t.accent, S.kyro === t.id, 1)).join("")}</div>` : ""}
    <p class="sa-grp">Make your own</p><div class="th-make">
      <div class="th-prev th-prev-lg" id="thPrev" style="background:${draft.bg}"><i style="background:${draft.panel}"></i><i style="background:${mix(draft.panel, "#ffffff", .05)}"></i><i style="background:${mix(draft.panel, "#ffffff", .11)}"></i><b style="background:${draft.accent}"></b></div>
      <div class="th-fields"><input type="text" class="th-name-in" id="thName" maxlength="20" placeholder="Theme name" value="${esc(draft.name)}" autocomplete="off" spellcheck="false">
      ${[["bg", "Background"], ["panel", "Panels"], ["accent", "Accent"]].map(([k, l]) => `<label><span>${l}</span><input type="color" data-c="${k}" value="${draft[k]}"></label>`).join("")}</div>
      <button class="sa-btn th-save" id="thSave">Save theme</button></div>
      <p class="th-hint">Changes preview live on the whole browser. Press Save to keep the theme.</p>`; }],
  ["background", "halftone", "Browser background", () =>
    '<p class="sa-grp">New tab</p>' +
    '<p class="bg-intro">Pick a subtle animated texture for your new-tab screen.</p>' +
    '<div class="bg-choice-grid">' +
      bgChoice("none", "Plain", "Use your theme as-is") +
      bgChoice("halftone", "Halftone", "Drifting print-screen dots") +
      bgChoice("topo", "Topo", "Animated contour lines") +
      bgChoice("smoke", "Smoke", "Flowing ink clouds") +
    '</div>' +
    '<p class="bg-hint">Background motion also follows the Reduce motion setting.</p>'],
  ["access", "gear", "Accessibility", () => '<p class="sa-grp">Display</p>' + row("Reduce motion", "Turn off interface animations", tg("motion", S.motion)) + row("Higher contrast text", "Brighten secondary text", tg("contrast", S.contrast))],
  ["system", "shield", "System", () =>
    '<p class="sa-grp">Backup</p>' +
    row("Save settings", "Download your settings and custom themes as a file", `<button class="sa-btn" data-act="export">Export</button>`) +
    row("Import settings", "Load a settings file you saved before", `<button class="sa-btn" data-act="import">Import</button>`) +
    '<p class="sa-grp">Reset</p>' +
    row("Reset settings", "Restore everything on this page to default", `<button class="sa-btn" data-act="reset">Reset</button>`) +
    '<p class="sa-grp">About</p>' +
    row("Vanta.cc", "Smart learning tools for students", `<span class="sa-info">v${APP_VERSION}</span>`)],
  ["credits", "gift", "Credits", () => {
    const it = (n, d) => `<div class="cr-item"><b>${n}</b><span>${d}</span></div>`;
    return '<p class="sa-grp">Kyro OS</p>' + it("Specxs", "Main UI · Other stuff") + it("Wroqz", "Menu UI · Game UI · Other stuff") +
      '<p class="sa-grp">Browse engine</p>' + it("Scramjet", "From Mercury Workshop.") + it("Epoxy transport and Wisp", "From Mercury Workshop.") + it("bare-mux", "From Mercury Workshop.") +
      '<p class="sa-grp">Typeface</p>' + it("Geist", "By Vercel, SIL Open Font License.") +
      '<p class="cr-foot">Settings layout ported from Kyro OS into Vanta.</p>';
  }]
];
const ICONS = {"appearance": "<circle cx=\"13.5\" cy=\"6.5\" r=\".6\"/><circle cx=\"17.5\" cy=\"10.5\" r=\".6\"/><circle cx=\"8.5\" cy=\"7.5\" r=\".6\"/><circle cx=\"6.5\" cy=\"12.5\" r=\".6\"/><path d=\"M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.93 0 1.65-.75 1.65-1.69 0-.44-.18-.84-.44-1.12-.29-.29-.44-.65-.44-1.13a1.64 1.64 0 0 1 1.67-1.67h2c3.05 0 5.55-2.5 5.55-5.55C21.97 6.01 17.46 2 12 2z\"/>", "themes": "<path d=\"m9.06 11.9 8.07-8.06a2.85 2.85 0 1 1 4.03 4.03l-8.06 8.08\"/><path d=\"M7.07 14.94c-1.66 0-3 1.35-3 3.02 0 1.33-2.5 1.52-2 2.02 1.08 1.1 2.49 2.02 4 2.02 2.2 0 4-1.8 4-4.04a3.01 3.01 0 0 0-3-3.02z\"/>", "browser": "<circle cx=\"12\" cy=\"12\" r=\"10\"/><path d=\"M2 12h20\"/><path d=\"M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z\"/>", "background": "<circle cx=\"12\" cy=\"12\" r=\"9\"/><circle cx=\"8\" cy=\"8\" r=\".8\"/><circle cx=\"12\" cy=\"8\" r=\".8\"/><circle cx=\"16\" cy=\"8\" r=\".8\"/><circle cx=\"8\" cy=\"12\" r=\".8\"/><circle cx=\"12\" cy=\"12\" r=\".8\"/><circle cx=\"16\" cy=\"12\" r=\".8\"/><circle cx=\"8\" cy=\"16\" r=\".8\"/><circle cx=\"12\" cy=\"16\" r=\".8\"/><circle cx=\"16\" cy=\"16\" r=\".8\"/>", "access": "<circle cx=\"16\" cy=\"4\" r=\"1\"/><path d=\"m18 19 1-7-6 1\"/><path d=\"m5 8 3-3 5.5 3-2.36 3.5\"/><path d=\"M4.24 14.5a5 5 0 0 0 6.88 6\"/><path d=\"M13.76 17.5a5 5 0 0 0-6.88-6\"/>", "system": "<circle cx=\"12\" cy=\"12\" r=\"10\"/><path d=\"M12 16v-4M12 8h.01\"/>", "credits": "<path d=\"M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7z\"/>"};
SEC.splice(1, 0, SEC.splice(2, 1)[0]);
const DESC = {
  appearance: "Colours, glass and texture for the whole browser.",
  themes: "Pick a look for Vanta, or make your own.",
  browser: "Proxy, search and how tabs are laid out.",
  background: "Choose the texture shown on the new-tab screen.",
  access: "Make Vanta easier on the eyes.",
  system: "Back up, restore or reset your settings.",
  credits: "Vanta.cc is built on these open-source projects. Big thanks to their creators."
};
const dlg = $("settingsPage");
const file = Object.assign(document.createElement("input"), { type: "file", accept: ".json", hidden: true }); dlg.appendChild(file);
let filter = "", lastKey = null;
const $f = $("spFilter");
function applyFilter(q) {
  const list = dlg.querySelector("#saList");
  let any = false;
  list.querySelectorAll(".sp-sec").forEach(sec => {
    const kids = [...sec.children].slice(1);
    let shown = sec.dataset.name.toLowerCase().includes(q), lastGrp = null, grpVis = false;
    if (!shown) {
      for (const k of kids) {
        if (k.classList.contains("sa-grp")) { if (lastGrp) lastGrp.hidden = !grpVis; lastGrp = k; grpVis = false; continue; }
        let vis;
        if (k.classList.contains("themes")) { let n = 0; k.querySelectorAll(".theme").forEach(b => { const m = b.textContent.toLowerCase().includes(q); b.hidden = !m; n += m; }); vis = n > 0; }
        else vis = k.textContent.toLowerCase().includes(q);
        k.hidden = !vis; if (vis) { grpVis = true; shown = true; }
      }
      if (lastGrp) lastGrp.hidden = !grpVis;
    }
    sec.hidden = !shown; any = any || shown;
  });
  if (!any) list.innerHTML = `<p class="sp-empty">No settings match “${esc(filter.trim())}”.</p>`;
}
function render() {
  if (cur !== "themes") apply();
  const sc = dlg.querySelector("#saScroll"), y = sc.scrollTop, s = SEC.find(x => x[0] === cur), q = filter.trim().toLowerCase();
  dlg.querySelector("#saNav").innerHTML = SEC.map(([id, , t]) => `<button class="sa-nav${!q && id === cur ? " on" : ""}" data-s="${id}"><svg viewBox="0 0 24 24">${ICONS[id]}</svg>${t}</button>`).join("");
  dlg.querySelector("#saHead").textContent = q ? "Search results" : s[2];
  dlg.querySelector("#saSub").textContent = q ? "Matches across every section." : DESC[cur];
  dlg.querySelector("#saList").innerHTML = q ? SEC.map(([, , t, fn]) => `<section class="sp-sec" data-name="${t}"><h3 class="sp-sech">${t}</h3>${fn()}</section>`).join("") : s[3]();
  if (q) applyFilter(q);
  sc.scrollTop = y;
  const key = q ? "search" : cur, lst = dlg.querySelector("#saList");
  if (key !== lastKey) { lst.classList.remove("enter"); void lst.offsetWidth; lst.classList.add("enter"); lastKey = key; } else lst.classList.remove("enter");
}
const clearFilter = () => { filter = ""; $f.value = ""; };
window.renderSettings = () => { lastKey = null; render(); };
window.gotoSettings = id => { if (SEC.some(x => x[0] === id)) { cur = id; clearFilter(); } };
$("openSettings").onclick = () => openSettingsTab();
$f.addEventListener("keydown", e => { if (e.key === "Escape" && filter) { e.stopPropagation(); clearFilter(); render(); } });
dlg.addEventListener("click", e => {
  const t = e.target, q = sel => t.closest(sel);
  let el;
  if ((el = q("[data-s]"))) { cur = el.dataset.s; clearFilter(); }
  else if ((el = q("[data-go]"))) { cur = el.dataset.go; clearFilter(); }
  else if ((el = q("[data-tg]"))) S[el.dataset.tg] = !S[el.dataset.tg];
  else if ((el = q("[data-bg]"))) S.background = el.dataset.bg;
  else if ((el = q("[data-sg]"))) { S[el.dataset.sg] = el.dataset.v; }
  else if ((el = q("[data-ac]"))) S.accent = el.dataset.ac;
  else if ((el = q(".theme"))) { S.kyro = ""; S.theme = el.dataset.pick; S.accent = ""; }
  else if ((el = q("[data-k]"))) { S.kyro = el.dataset.k; S.accent = ""; }
  else if ((el = q("[data-del]"))) { S.custom = S.custom.filter(c => c.id !== el.dataset.del); if (S.kyro === el.dataset.del) S.kyro = ""; }
  else if (q("#thSave")) { const id = "c" + Date.now().toString(36); S.custom.push({ id, name: draft.name.trim() || "My theme", bg: draft.bg, panel: draft.panel, accent: draft.accent }); S.kyro = id; S.accent = ""; }
  else if ((el = q("[data-act]"))) {
    const a = el.dataset.act;
    if (a === "export") { const u = URL.createObjectURL(new Blob([JSON.stringify({ app: "vanta", settings: S }, null, 2)], { type: "application/json" })); Object.assign(document.createElement("a"), { href: u, download: "vanta-settings.json" }).click(); setTimeout(() => URL.revokeObjectURL(u), 2000); return; }
    if (a === "import") return file.click();
    if (a === "openBlank") {
      const blank = window.open("about:blank", "_blank");
      if (!blank) { flash("Allow pop-ups to open Vanta in a blank tab."); return; }
      const frame = blank.document.createElement("iframe");
      frame.src = location.href;
      frame.title = "Vanta.cc";
      frame.allow = "storage-access; autoplay; fullscreen; encrypted-media; picture-in-picture; gamepad; pointer-lock; clipboard-read; clipboard-write";
      frame.referrerPolicy = "no-referrer";
      frame.style.cssText = "position:fixed;inset:0;width:100%;height:100%;border:0;display:block";
      blank.document.title = "Vanta.cc";
      blank.document.documentElement.style.height = "100%";
      blank.document.body.style.cssText = "margin:0;height:100vh;overflow:hidden;background:#111";
      blank.document.body.appendChild(frame);
      return;
    }
    if (a === "fixproxy") {
      el.textContent = "Resetting…";
      PROXY.reset().then(() => location.reload()).catch(error => {
        el.textContent = "Reset";
        flash("Could not reset proxy data: " + error.message);
      });
      return;
    }
    if (a === "reset") S = Object.assign({}, DEF, { custom: S.custom });
  } else if (!q("input")) return;
  if (t.closest("input")) return;
  save(); apply(); render(); pushAdblock();
  if (el && el.dataset && el.dataset.tg === "proxy" && active && active.pos >= 0) show(active.hist[active.pos], false);
});
dlg.addEventListener("input", e => {
  const t = e.target;
  if (t.dataset.rg) { S[t.dataset.rg] = +t.value; t.nextElementSibling.textContent = t.value + t.dataset.u; save(); apply(); }
  else if (t.id === "spFilter") { filter = t.value; render(); }
  else if (t.id === "thName") draft.name = t.value;
  else if (t.dataset.c) { draft[t.dataset.c] = t.value; if (document.documentElement.dataset.theme !== "kyro") document.documentElement.dataset.theme = "kyro"; const st = document.documentElement.style; st.setProperty("--bg", draft.bg); st.setProperty("--accent", draft.accent); st.setProperty("--panel", draft.panel); st.setProperty("--k1", draft.panel); st.setProperty("--dlg", draft.panel);
    const pv = dlg.querySelector("#thPrev"), q = pv.querySelectorAll("i"); pv.style.background = draft.bg; q[0].style.background = draft.panel; q[1].style.background = mix(draft.panel, "#ffffff", .05); q[2].style.background = mix(draft.panel, "#ffffff", .11); pv.querySelector("b").style.background = draft.accent; dlg.querySelectorAll(".th-card.on").forEach(x => x.classList.remove("on")); }
});
file.onchange = () => {
  const f = file.files[0]; file.value = ""; if (!f || f.size > 1e6) return;
  const rd = new FileReader(); rd.onload = () => { try {
    const d = JSON.parse(rd.result); if (!d || !d.settings) throw 0;
    const n = Object.assign({}, DEF); Object.keys(DEF).forEach(k => { if (k in d.settings && typeof d.settings[k] === typeof DEF[k]) n[k] = d.settings[k]; });
    if (!("background" in d.settings) && typeof d.settings.halftone === "boolean") n.background = d.settings.halftone ? "halftone" : "none";
    if (!["none", "halftone", "topo", "smoke"].includes(n.background)) n.background = "halftone";
    n.custom = n.custom.filter(c => c && c.id && hex(c.bg) && hex(c.panel) && hex(c.accent)).slice(0, 40);
    S = n; save(); apply(); render();
  } catch { flash("That is not a valid settings file."); } }; rd.readAsText(f);
};
apply();
})();
