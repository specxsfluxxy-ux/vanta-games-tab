// Vanta.cc settings
//
// MULLVAD_PROXY: base URL of a proxy YOU run that sends traffic out through a
// Mullvad exit. Requests look like  {MULLVAD_PROXY}/{country}/?url=<target>
// Leave it empty and the VPN panel points to the official Mullvad app instead.
const MULLVAD_PROXY = "";

// Shown in the VPN window header (cosmetic).
const DEVICE_NAME = "Known Gecko";
const TIME_LEFT = "29 days";

const SEARCH_URL = "https://www.google.com/search?igu=1&q=";

const LOCATIONS = [
  // srv / inIp / outIp are display-only placeholders for the connected view.
  { code: "se", name: "Sweden",         city: "Gothenburg", lat: 57.71, lon: 11.97,  srv: "se-got-wg-004", inIp: "203.0.113.24:44993 UDP", outIp: "203.0.113.31" },
  { code: "ch", name: "Switzerland",    city: "Zurich",     lat: 47.38, lon: 8.54,   srv: "ch-zrh-wg-002", inIp: "203.0.113.57:44993 UDP", outIp: "203.0.113.64" },
  { code: "de", name: "Germany",        city: "Frankfurt",  lat: 50.11, lon: 8.68,   srv: "de-fra-wg-007", inIp: "203.0.113.88:44993 UDP", outIp: "203.0.113.95" },
  { code: "nl", name: "Netherlands",    city: "Amsterdam",  lat: 52.37, lon: 4.90,   srv: "nl-ams-wg-003", inIp: "203.0.113.112:44993 UDP", outIp: "203.0.113.119" },
  { code: "gb", name: "United Kingdom", city: "London",     lat: 51.51, lon: -0.13,  srv: "gb-lon-wg-005", inIp: "203.0.113.140:44993 UDP", outIp: "203.0.113.147" },
  { code: "us", name: "United States",  city: "New York",   lat: 40.71, lon: -74.01, srv: "us-nyc-wg-201", inIp: "203.0.113.168:44993 UDP", outIp: "203.0.113.175" },
  { code: "ca", name: "Canada",         city: "Toronto",    lat: 43.65, lon: -79.38, srv: "ca-tor-wg-008", inIp: "203.0.113.196:44993 UDP", outIp: "203.0.113.203" },
  { code: "jp", name: "Japan",          city: "Tokyo",      lat: 35.68, lon: 139.69, srv: "jp-tyo-wg-004", inIp: "203.0.113.224:44993 UDP", outIp: "203.0.113.231" }
];
