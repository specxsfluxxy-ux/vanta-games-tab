/* Login / sign up (username + password) and the AI assistant. Loads after settings.js. */
(() => {
const api = async (path, body) => {
  try {
    const r = await fetch("/api/" + path, { ...(body ? { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) } : {}), credentials: "same-origin" });
    const j = await r.json().catch(() => ({}));
    return r.ok ? j : { error: j.error || "Something went wrong" };
  } catch { return { error: "Can’t reach the server. Is it running?" }; }
};
const ic = p => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
const IC = { chat: ic('<path d="M6 4.5h12A1.5 1.5 0 0 1 19.5 6v9a1.5 1.5 0 0 1-1.5 1.5h-6.5L7.500 20v-3.500H6A1.5 1.5 0 0 1 4.500 15V6A1.5 1.5 0 0 1 6 4.500z"/>'), out: ic('<path d="M10 4.500H6.500A1.500 1.500 0 0 0 5 6v12a1.500 1.500 0 0 0 1.500 1.500H10"/><path d="M14.500 8.500 18 12l-3.500 3.500M18 12H9.500"/>'), chev: ic('<path d="m9.500 6 6 6-6 6"/>') };
const PFP = '<svg class="pfp" viewBox="0 0 100 100" aria-hidden="true"><circle cx="50" cy="50" r="50" fill="#d2d2d2"/><circle cx="50" cy="43" r="18.7" fill="#9b9b9b"/><path d="M12.73 83.33A39 26 0 0 1 87.27 83.33A50 50 0 0 1 12.73 83.33Z" fill="#9b9b9b"/></svg>';
const X = '<svg><use href="#i-x"/></svg>';
let user = null, aiReady = false, models = [], selectedModel = "", mode = "login", chat = [], busy = false, authReady = false, authRevision = 0;

const acct = document.createElement("div"); acct.className = "scrim"; acct.id = "acctScrim";
acct.innerHTML = '<div class="dlg acct" role="dialog" aria-modal="true" aria-labelledby="acctTitle"><div class="dlg-h"><h2 id="acctTitle">Account</h2><button class="ib" data-x aria-label="Close">' + X + '</button></div><div class="dlg-b" id="acctBody"></div></div>';
const ai = document.createElement("div"); ai.className = "scrim"; ai.id = "aiScrim";
ai.innerHTML = '<div class="dlg aichat" role="dialog" aria-modal="true" aria-labelledby="aiTitle"><div class="dlg-h"><div class="ai-heading"><h2 id="aiTitle">Assistant</h2><label class="ai-model" id="aiModelLabel">Model<select id="aiModel" aria-label="AI model"></select></label></div><button class="ib" data-x aria-label="Close">' + X + '</button></div><div class="dlg-b" id="aiLog"></div><div class="ai-share" id="aiShareBar" hidden><span class="ai-live"></span><span>Sharing your screen. A snapshot is sent with each message.</span><button type="button" id="aiStop">Stop</button></div><form class="ai-f" id="aiForm"><button type="button" class="ib ai-scr" id="aiShare" title="Share your screen" aria-label="Share your screen"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/></svg></button><textarea id="aiIn" rows="1" maxlength="4000" placeholder="Ask anything…" aria-label="Message"></textarea><button class="btn" id="aiSend" type="submit">Send</button></form></div>';
document.body.append(acct, ai);
const $ = id => document.getElementById(id);
const close = el => el.classList.remove("open");
[acct, ai].forEach(el => { el.addEventListener("click", e => { if (e.target === el || e.target.closest("[data-x]")) { close(el); if (el === ai) stopShare(); } }); });
addEventListener("keydown", e => { if (e.key === "Escape") { close(acct); close(ai); stopShare(); } });

function setAccountInfo(info) {
  if (Array.isArray(info.models)) models = info.models.filter(m => m && typeof m.id === "string" && typeof m.name === "string");
  aiReady = !!info.ai;
  const select = $("aiModel");
  select.replaceChildren(...models.map(model => {
    const option = document.createElement("option");
    option.value = model.id;
    option.textContent = model.name;
    return option;
  }));
  const fallback = models.some(model => model.id === info.defaultModel) ? info.defaultModel : models[0]?.id || "";
  if (!models.some(model => model.id === selectedModel)) selectedModel = fallback;
  select.value = selectedModel;
  $("aiModelLabel").hidden = !models.length || !aiReady;
}
$("aiModel").onchange = e => { selectedModel = e.target.value; };

function pill() { $("loginPill").textContent = user ? user : ""; const n = document.getElementById("sbName"); if (n) n.textContent = user || "Guest"; }
function drawAcct(msg) {
  const b = $("acctBody");
  if (user) {
    $("acctTitle").textContent = "Account";
    b.innerHTML = `<div class="acct-me">${PFP}<b></b><span><i></i>Signed in</span></div><div class="acct-list"><button class="acct-row" id="goAi">${IC.chat}<span>Open assistant</span>${IC.chev.replace("<svg", '<svg class="chev"')}</button><button class="acct-row out" id="goOut">${IC.out}<span>Log out</span></button></div>`;
    b.querySelector("b").textContent = user;
    $("goAi").onclick = () => { close(acct); openAi(); };
    $("goOut").onclick = async () => { authRevision++; await api("logout", {}); user = null; chat = []; pill(); drawAcct(); };
    return;
  }
  const su = mode === "signup";
  $("acctTitle").textContent = su ? "Sign up" : "Log in";
  b.innerHTML = `<div class="acct-tabs"><button data-m="login" class="${su ? "" : "on"}">Log in</button><button data-m="signup" class="${su ? "on" : ""}">Sign up</button></div>
  ${msg ? `<p class="acct-intro"></p>` : ""}
  <form id="acctForm" novalidate>
  <label>Username<span class="fld"><input id="acU" autocomplete="username" maxlength="20" spellcheck="false" autocapitalize="none" placeholder="your_username"></span></label>
  <label>Password<span class="fld"><input id="acP" type="password" autocomplete="${su ? "new-password" : "current-password"}" maxlength="72" placeholder="${su ? "At least 6 characters" : "Your password"}"><button type="button" class="eye" id="acEye" aria-label="Show password">Show</button></span></label>
  <div class="acct-err" id="acE" role="alert"></div><button class="btn" id="acGo" type="submit"><span>${su ? "Create account" : "Log in"}</span></button></form>
  <p class="acct-note">${su ? "No email needed, just a username and password." : `New here? <button type="button" class="lnk" data-m="signup">Create an account</button>`}</p>`;
  if (msg) b.querySelector(".acct-intro").textContent = msg;
  b.querySelectorAll("[data-m]").forEach(t => t.onclick = () => { keepU = $("acU").value; mode = t.dataset.m; drawAcct(msg); });
  $("acEye").onclick = () => { const p = $("acP"), show = p.type === "password"; p.type = show ? "text" : "password"; $("acEye").textContent = show ? "Hide" : "Show"; $("acEye").setAttribute("aria-label", show ? "Hide password" : "Show password"); };
  $("acctForm").onsubmit = async e => {
    e.preventDefault();
    const go = $("acGo"), er = $("acE"); er.textContent = ""; go.disabled = true; go.querySelector("span").textContent = su ? "Creating…" : "Logging in…";
    const r = await api(su ? "signup" : "login", { username: $("acU").value, password: $("acP").value });
    go.disabled = false; go.querySelector("span").textContent = su ? "Create account" : "Log in";
    if (r.error) { er.textContent = r.error; return; }
    authRevision++; user = r.user; pill(); drawAcct();
    setAccountInfo(r);
    if (wantAi) { wantAi = false; close(acct); openAi(); }
  };
  $("acU").value = keepU; setTimeout(() => $("acU") && $("acU").focus(), 30);
}
let wantAi = false, keepU = "";
function openAcct(msg) { document.getElementById("menu").classList.remove("open"); drawAcct(msg); acct.classList.add("open"); }

/* ---- Screen sharing: user picks a screen/window/tab; we grab one frame per message ---- */
let stream = null, video = null;
const canShare = !!(navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia);
function syncShare() {
  const on = !!stream;
  $("aiShareBar").hidden = !on;
  $("aiShare").classList.toggle("on", on);
  $("aiShare").title = on ? "Stop sharing" : "Share your screen";
}
function stopShare() {
  if (stream) stream.getTracks().forEach(t => t.stop());
  stream = null; if (video) { video.srcObject = null; video = null; }
  syncShare();
}
async function startShare() {
  try {
    stream = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: 5 }, audio: false });
  } catch { stream = null; return; }
  video = document.createElement("video"); video.muted = true; video.playsInline = true; video.srcObject = stream;
  stream.getVideoTracks()[0].addEventListener("ended", stopShare);
  await video.play().catch(() => {});
  syncShare();
}
function grabFrame() {
  if (!stream || !video || !video.videoWidth) return null;
  const k = Math.min(1, 1280 / Math.max(video.videoWidth, video.videoHeight));
  const c = document.createElement("canvas"); c.width = Math.round(video.videoWidth * k); c.height = Math.round(video.videoHeight * k);
  c.getContext("2d").drawImage(video, 0, 0, c.width, c.height);
  return c.toDataURL("image/jpeg", 0.72);
}
if (!canShare) $("aiShare").hidden = true;
$("aiShare").onclick = () => stream ? stopShare() : startShare();
$("aiStop").onclick = stopShare;
const visionOk = () => (models.find(m => m.id === selectedModel) || {}).vision;

const seen = new WeakSet();
function drawLog() {
  const l = $("aiLog");
  if (!chat.length) { l.innerHTML = '<div class="ai-empty"><b>How can I help?</b>Ask about homework, a topic you’re stuck on, or ideas for a project.</div>'; return; }
  l.innerHTML = "";
  chat.forEach(m => { const d = document.createElement("div"); d.className = "ai-m " + (m.role === "user" ? "u" : "a") + (m.err ? " err" : "") + (m.wait ? " wait" : "") + (seen.has(m) ? "" : " pop"); seen.add(m); d.textContent = m.content; if (m.img) { const im = document.createElement("img"); im.src = m.img; im.alt = "Screen snapshot"; im.className = "ai-shot"; d.prepend(im); } l.appendChild(d); });
  l.scrollTop = l.scrollHeight;
}
function openAi() {
  document.getElementById("menu").classList.remove("open");
  if (!authReady) { wantAi = true; return; }
  if (!user) { wantAi = true; return openAcct("Log in to use the assistant."); }
  chat.forEach(m => seen.add(m)); drawLog(); ai.classList.add("open"); setTimeout(() => $("aiIn").focus(), 30);
}
$("aiForm").onsubmit = async e => {
  e.preventDefault();
  const inp = $("aiIn"), text = inp.value.trim();
  if (!text || busy) return;
  busy = true; $("aiSend").disabled = true; inp.value = ""; inp.style.height = "";
  let img = null;
  if (stream) {
    if (!visionOk()) { chat.push({ role: "assistant", content: "This model can’t see images. Pick GPT-4o mini, GPT-4.1 mini, Gemini or Claude from the model list, or stop sharing.", err: true }); drawLog(); busy = false; $("aiSend").disabled = false; inp.value = text; return; }
    img = grabFrame();
  }
  chat.push({ role: "user", content: text, img }); chat.push({ role: "assistant", content: "Thinking…", wait: true }); drawLog();
  const requestAuthRevision = authRevision;
  const last = chat.length - 2;
  const r = await api("ai", { model: selectedModel, messages: chat.filter(m => !m.wait && !m.err).map((m, i, a) => ({ role: m.role, content: m.content, ...(m.img && m === chat[last] ? { image: m.img } : {}) })) });
  chat.pop();
  if (r.error) {
    if (/log in/i.test(r.error) && requestAuthRevision === authRevision) { authRevision++; user = null; pill(); }
    chat.push({ role: "assistant", content: r.error, err: true });
  } else chat.push({ role: "assistant", content: r.text || "(no reply)" });
  busy = false; $("aiSend").disabled = false; drawLog(); inp.focus();
};
$("aiIn").addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); $("aiForm").requestSubmit(); } });
$("aiIn").addEventListener("input", e => { e.target.style.height = "auto"; e.target.style.height = Math.min(120, e.target.scrollHeight) + "px"; });

$("openLogin").onclick = () => openAcct();
document.querySelectorAll(".tile").forEach(t => { if ((t.dataset.url || "").includes("claude.ai")) t.dataset.ai = "1"; });
document.addEventListener("click", e => {
  const t = e.target.closest(".tile[data-ai]");
  if (t) { e.stopImmediatePropagation(); e.preventDefault(); openAi(); }
}, true);
const ab = document.querySelector('.ib[aria-label="Assistant"]'); if (ab) ab.onclick = openAi;

const initialAuthRevision = authRevision;
api("me").then(r => {
  authReady = true;
  if (initialAuthRevision !== authRevision) return;
  if (r && !r.error) { user = r.user; setAccountInfo(r); pill(); }
  if (wantAi) {
    if (user) { wantAi = false; close(acct); openAi(); }
    else openAcct("Log in to use the assistant.");
  }
});
})();
