// Scramjet service worker (must live at the site root).
importScripts("/scram/scramjet.all.js");
const { ScramjetServiceWorker } = $scramjetLoadWorker();
const scramjet = new ScramjetServiceWorker();
const SCRAMJET_DB_VERSION = 3;
const indexedDBOpen = indexedDB.open.bind(indexedDB);
indexedDB.open = (name, version, ...options) =>
  indexedDBOpen(name, name === "$scramjet" ? SCRAMJET_DB_VERSION : version, ...options);


/* ---- Ad blocker: drops requests to known ad / tracker hosts before they reach the proxy ---- */
const AD_HOSTS = ["doubleclick.net","googlesyndication.com","googleadservices.com","adservice.google.com","pagead2.googlesyndication.com","tpc.googlesyndication.com","adsystem.com","2mdn.net","adnxs.com","adsrvr.org","adform.net","advertising.com","amazon-adsystem.com","criteo.com","criteo.net","taboola.com","outbrain.com","revcontent.com","mgid.com","pubmatic.com","rubiconproject.com","openx.net","casalemedia.com","indexww.com","contextweb.com","media.net","smartadserver.com","yieldmo.com","sharethrough.com","triplelift.com","teads.tv","spotxchange.com","springserve.com","moatads.com","adsafeprotected.com","serving-sys.com","bidswitch.net","lijit.com","sovrn.com","gumgum.com","33across.com","zedo.com","popads.net","popcash.net","propellerads.com","exoclick.com","juicyads.com","trafficjunky.net","adcash.com","clickadu.com","hilltopads.net","adskeeper.com","ad.gt","adsco.re","ads.yahoo.com","advertising.yahoo.com","ads.pubmatic.com","ads.twitter.com","ads.linkedin.com","an.facebook.com","ads.tiktok.com","analytics.tiktok.com"];
const TRACK_HOSTS = ["google-analytics.com","analytics.google.com","googletagmanager.com","googletagservices.com","scorecardresearch.com","quantserve.com","hotjar.com","hotjar.io","mixpanel.com","segment.io","segment.com","amplitude.com","fullstory.com","mouseflow.com","crazyegg.com","clarity.ms","newrelic.com","nr-data.net","chartbeat.com","chartbeat.net","parsely.com","krxd.net","bluekai.com","demdex.net","omtrdc.net","everesttech.net","adobedtm.com","branch.io","adjust.com","appsflyer.com","connect.facebook.net","pixel.facebook.com","bat.bing.com","px.ads.linkedin.com","snap.licdn.com","sentry.io","bugsnag.com"];
const AD_PATH = /(\/pagead\/|\/adsbygoogle|\/ads\/(?:show|js|banner)|\/adserver|[?&\/_.-]ad_?(?:slot|unit|banner)s?[=\/_.-]|\/prebid|\/googleads|\/doubleclick\/)/i;
let adCfg = null, adCount = 0;
const CFG_URL = "https://vanta.invalid/adblock-config";
async function loadAdCfg() {
  if (adCfg) return adCfg;
  try { const c = await caches.open("vanta-cfg"), r = await c.match(CFG_URL); adCfg = r ? await r.json() : { on: true, level: "ads" }; }
  catch { adCfg = { on: true, level: "ads" }; }
  return adCfg;
}
const hostHit = (host, list) => list.some(d => host === d || host.endsWith("." + d));
function targetOf(request) {
  const i = request.url.indexOf("/~/scramjet/");
  if (i < 0) return null;
  const raw = request.url.slice(i + 12);
  try { return new URL(decodeURIComponent(raw)); } catch { return null; }
}
async function shouldBlock(request) {
  const cfg = await loadAdCfg();
  if (!cfg.on || request.destination === "document") return false;
  const u = targetOf(request);
  if (!u) return false;
  const host = u.hostname.toLowerCase();
  if (hostHit(host, AD_HOSTS)) return true;
  if (cfg.level === "strict" && hostHit(host, TRACK_HOSTS)) return true;
  return AD_PATH.test(u.pathname + u.search) && !/^(?:[a-z0-9-]+\.)*(?:youtube|google)\.com$/.test(host);
}
const GIF = Uint8Array.from(atob("R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"), c => c.charCodeAt(0));
function blockedResponse(request) {
  const d = request.destination;
  if (d === "script" || d === "worker") return new Response("", { status: 200, headers: { "content-type": "application/javascript" } });
  if (d === "style") return new Response("", { status: 200, headers: { "content-type": "text/css" } });
  if (d === "image") return new Response(GIF, { status: 200, headers: { "content-type": "image/gif" } });
  if (d === "iframe" || d === "frame") return new Response("<!doctype html><title></title>", { status: 200, headers: { "content-type": "text/html" } });
  return new Response(null, { status: 204 });
}
async function countBlock() {
  adCount++;
  const list = await self.clients.matchAll({ type: "window" });
  list.forEach(c => c.postMessage({ type: "vanta:blocked", n: adCount }));
}
self.addEventListener("message", event => {
  if (event.data?.type !== "vanta:adblock") return;
  adCfg = { on: event.data.on !== false, level: event.data.level === "strict" ? "strict" : "ads" };
  event.waitUntil(caches.open("vanta-cfg").then(c => c.put(CFG_URL, new Response(JSON.stringify(adCfg)))).catch(() => {}));
});

self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", e => e.waitUntil(self.clients.claim()));
self.addEventListener("message", event => {
  if (event.data?.type !== "vanta:proxy-reset") return;
  event.ports[0]?.postMessage({ ok: true });
  setTimeout(() => self.close(), 0);
});
self.addEventListener("fetch", event => {
  event.respondWith((async () => {
    try {
      await scramjet.loadConfig();
    } catch (error) {
      console.error("[Vanta service worker] Scramjet config unavailable; loading request directly.", error);
      return fetch(event.request);
    }
    if (scramjet.route(event)) {
      if (await shouldBlock(event.request)) { countBlock(); return blockedResponse(event.request); }
      return scramjet.fetch(event);
    }
    return fetch(event.request);
  })());
});
