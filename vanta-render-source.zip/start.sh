#!/bin/sh
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Install Node.js from https://nodejs.org first"; exit 1; }
[ -d node_modules/@mercuryworkshop ] || npm install || exit 1
(sleep 3; xdg-open http://localhost:8080 2>/dev/null || open http://localhost:8080 2>/dev/null) &
node server.mjs
