// Usage: node tools/import-games.mjs <path-to-seraph-games-folder> [--all]
// Copies half of the games (every other one, alphabetically) into public/games and writes games.json.
import { readdirSync, statSync, existsSync, cpSync, readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { join, resolve } from "node:path";

const src = process.argv[2], all = process.argv.includes("--all");
if (!src || !existsSync(src)) { console.error("Usage: node tools/import-games.mjs <seraph games folder> [--all]"); process.exit(1); }
const out = resolve(new URL("../public/games", import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, "$1"));
mkdirSync(out, { recursive: true });

const dirs = readdirSync(src).filter(n => !n.startsWith(".") && statSync(join(src, n)).isDirectory()
  && existsSync(join(src, n, "index.html"))).sort((a, b) => a.localeCompare(b));
const picked = all ? dirs : dirs.filter((_, i) => i % 2 === 0);

const pretty = n => n.replace(/[-_.]+/g, " ").replace(/\b\w/g, c => c.toUpperCase()).trim();
const manifest = [];
for (const name of picked) {
  const from = join(src, name), to = join(out, name);
  cpSync(from, to, { recursive: true });
  const html = readFileSync(join(from, "index.html"), "utf8");
  const title = (html.match(/<title>([^<]{1,80})<\/title>/i)?.[1] || "").trim();
  const files = readdirSync(from);
  const thumb = files.find(f => /^(thumb|thumbnail|icon|cover|logo|poster|preview)\.(png|jpe?g|webp|gif|svg)$/i.test(f))
    || files.find(f => /\.(png|jpe?g|webp)$/i.test(f) && statSync(join(from, f)).size < 400_000);
  manifest.push({ id: name, title: title && title.length > 2 ? title : pretty(name), ...(thumb ? { thumb } : {}) });
}
writeFileSync(join(out, "games.json"), JSON.stringify(manifest, null, 1));
console.log(`Imported ${manifest.length} of ${dirs.length} games into public/games`);
