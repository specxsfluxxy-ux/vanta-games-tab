# Vanta.cc

## Run it
```
npm install
npm start        # http://localhost:8080
```
Open it through that address. The proxy cannot work from a file:// page, and a public site needs HTTPS
(service workers only run on https or localhost).

## How the proxy works
- `public/sw.js` – Scramjet service worker (site root).
- `public/js/proxy.js` – upgrades Scramjet's IndexedDB schema to version 3 before registering the service worker, then points bare-mux at the epoxy transport over `/wisp/`. Settings → Browser → Fix proxy unregisters the worker and clears this database; close other Vanta tabs first if the browser reports that the database is still in use.
- `server.mjs` – serves the site, `/scram/`, `/baremux/`, `/epoxy/`, and the Wisp websocket.
- `public/js/app.js` – every page load goes through `PROXY.sj.encodeUrl(url)`; if the proxy fails
  to start it falls back to loading pages directly and shows a notice.

The exit IP/location is whatever network the Node server runs on. The Mullvad panel is only a visual.
Browser pages grant gamepad and pointer-lock access for cloud gaming. Streaming quality and site
availability still depend on the server's network and exit IP; a code change cannot fix restrictions
or latency imposed by the hosting provider or the game-streaming service.

If Scramjet's API has changed (it is under heavy development), compare `sw.js` and `proxy.js` with
https://github.com/MercuryWorkshop/Scramjet-App and pin the package versions that repo uses.

## Quick start
Double-click `start.bat` (Windows) or run `./start.sh` (Mac/Linux). It installs once, starts the server and opens http://localhost:8080.
Turn the proxy on or off in Settings → Browser → Proxy (or press Ctrl+,).

## Layout
Settings → Browser → Tab layout switches between **Top tabs** and **Sidebar** (vertical tabs, address bar and controls in a left rail). Ctrl+B hides the sidebar, Ctrl+L focuses the address bar. The default theme is **Ink**, a flat, solid look with no glow or blur.
Settings → Browser background selects Plain, Halftone, Topo, or Smoke for the new-tab background. The animations respect Reduce motion.

## Browser sessions
Vanta saves open tabs and their in-app back/forward history in this browser profile and restores them on the next visit. Only the active page is loaded during startup; other saved pages load when selected. Clearing this site's local storage clears the saved session.

## Games
The Games tab lists the game folders from [a456pur/seraph](https://github.com/a456pur/seraph), with game artwork from Seraph's thumbnail collection, and streams requested files from a pinned upstream commit, so the multi-gigabyte games collection is not copied into this project. A letter icon is shown only when no matching thumbnail is available. Playing these games requires an internet connection. The server only proxies paths for games in the manifest; an opaque-origin iframe sandbox prevents access to Vanta, popups, and top-level navigation, while a restrictive content security policy limits external resources and network APIs. Some games may not work fully if they depend on browser storage or external services. This reduces risk, but does not constitute a full audit of every third-party game. The existing `tools/import-games.mjs` script remains available for importing a local games folder.

## Accounts and the AI assistant
Copy `.env.example` to `.env`, set `OPENROUTER_API_KEY` to a private key from OpenRouter, and restart the server. `OPENROUTER_MODEL` defaults to `openai/gpt-4o-mini` and sets the assistant's initial selection. Signed-in users can switch among the supported OpenRouter models in the assistant; the server validates each selection. A configured default not in the built-in list is also available as a custom default. Menu (⋮) → Login to sign up with a username and password. The key stays on the server and is never sent to the browser. Accounts are stored hashed in `data/users.json`; hashed login sessions persist in `data/sessions.json`, so a server restart won’t log users out.

## Production / publishing checklist
Before publishing this app, treat all secrets as production-only values:
- Rotate any real AI keys or credentials before committing, uploading, or deploying.
- Keep `.env` local and never include it in source control, Docker images, or release archives.
- Use an environment secrets manager or platform secret store in deployment instead of baking secrets into the container.
- Keep the app behind HTTPS only and set a trusted certificate or reverse proxy in front of it.
- Persist `data/` on a writable volume, because it stores hashed user accounts and login sessions.
- Review the game sandbox and proxy settings as a reduced-risk measure rather than a full security audit for third-party content.

The project already has a `.dockerignore` entry that excludes `.env` and key files, and the `Dockerfile` is intentionally set up so public image builds do not include local secrets.

## Deploy to Render
Render deploys from a connected Git repository or a Docker image; it does not accept a source ZIP as a deploy source. Extract the ZIP, put the source in a Git repository, then create a Blueprint in Render from that repository. Render will use `render.yaml` to build the Dockerfile and attach a 1 GB persistent disk at `/app/data`.

The Blueprint uses a paid web-service plan because persistent disks require one. The disk keeps new Render accounts and sessions across restarts, but local `data/` files are intentionally excluded from the source ZIP. Add `OPENROUTER_API_KEY` in Render’s environment settings only if you want the AI assistant enabled; never put the key in the ZIP.
