@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js is not installed. Get it from https://nodejs.org, then run this again. & pause & exit /b)
if not exist node_modules\@mercuryworkshop call npm install
if errorlevel 1 (echo npm install failed. Check your internet connection. & pause & exit /b)
start "" cmd /c "timeout /t 3 /nobreak >nul & start http://localhost:8080"
node server.mjs
pause
